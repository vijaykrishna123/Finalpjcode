export default {
  envName: "stg",
  url: "https://capgroup-qa.oktapreview.com",
  issuer: "https://capgroup-qa.oktapreview.com/oauth2/ause6w9ae5LHH6k910h7",
  redirect_uri: window.location.origin + "/implicit/callback",
  client_id: "0oaiaqu6m2tKZcwht0h7",
  scopes: ["openid", "profile", "email", "advanced-search-api"],
  daaUrl: "https://discover.stg.capgroup.com",
  cwbApiEndpoint: "/api/cwb/v1",
  cmpApiEndpoint: "/api/cmp/v1",
  legalApiEndpoint: "/api/legal/v1",
  discoverApi: "https://azure-apigw-oztest.capgroup.com",
  OcpApimSubscriptionKey: "676dbeda997d4964b6833669b3e9e368",
  workfronturl: "https://capitalgroup.preview.workfront.com/task/view?ID=",
  includeAnalytics: true,
  edamURL: "https://edam.stg.capitalgroup.com"
};
