export default {
  envName: "prod",
  url: "https://capgroup.okta.com",
  issuer: "https://capgroup.okta.com/oauth2/aus1eudbd2yFTHt7w1d8",
  redirect_uri: window.location.origin + "/implicit/callback",
  client_id: "0oa1f742vqqOl9gSS1d8",
  scopes: ["openid", "profile", "email", "advanced-search-api"],
  daaUrl: "https://discover.capgroup.com",
  cwbApiEndpoint: "/api/cwb/v1",
  cmpApiEndpoint: "/api/cmp/v1",
  legalApiEndpoint: "/api/legal/v1",
  discoverApi: "https://azure-apigw.capgroup.com",
  OcpApimSubscriptionKey: "f3352e9e90344e6fbdf7d0f241b01c75",
  workfronturl: "https://capitalgroup.my.workfront.com/task/view?ID=",
  includeAnalytics: true,
  edamURL: "https://edam.capitalgroup.com"
};
