import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
const styles = theme => {
  return {
    root: {
      width: "33%",
      position: "fixed",
      top: 0,
      right: 0,
      paddingTop: "1rem",
      height: "100vh",
      overflowY: "scroll",
      transition: "500ms"
    },
    contentWrapper: {
      flex: 1,
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: "#00353c",
      width: "100%",
      padding: "1rem"
    },
    content: {
      width: "100%",
      marginTop: "3rem"
    },
    buttonWrapper: {
      display: "flex",
      backgroundColor: "#00353c",
      flexDirection: "row",
      alignItems: "flex-end",
      justifyContent: "center"
    },
    closeButton: {}
  };
};

class Modal extends Component {
  formatSelection(e) {
    if (e.ctrlKey && e.which == 66) {
      setTimeout(() => document.execCommand("bold"), 1000);
      window.getSelection().empty();
    } else if (e.ctrlKey && e.which == 117) {
      setTimeout(() => document.execCommand("underline"), 1000);
      window.getSelection().empty();
    } else if (e.ctrlKey && e.which == 73) {
      setTimeout(() => document.execCommand("italic"), 1000);
      window.getSelection().empty();
    }
  }

  render() {
    const { classes } = this.props;
    return (
      <div className={classes.root}>
        <div className={classes.contentWrapper}>
          <div className={classes.content}>{this.props.children}</div>
        </div>
      </div>
    );
  }
}

export default withStyles(styles)(Modal);
