import React from "react";
import {
  Input,
  Dialog,
  DialogContent,
  Typography,
  TextField
} from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import "./../../assets/scss/modals.css";
import Card from "./ShareCard";

const styles = theme => ({
  dialogContent: {
    padding: "0 24px",
    backgroundColor: "#f2f2f2"
  },
  dialogContainer: {
    minWidth: 450,
    maxWidth: 800,
    width: "100%",
    height: 550
  },
  title: {
    fontWeight: "bold",
    fontSize: "1.125em",
    padding: "9px 19px 5px 19px",
    height: "32px",
    backgroundColor: "#e5e5e5"
  },
  to: {
    fontWeight: "bold",
    fontSize: "1em",
    marginTop: "36px"
  },
  email: {
    width: "100%",
    marginRight: "auto",
    marginTop: "21px",
    border: "1px solid #e5e5e5",
    backgroundColor: "#ffffff",
    borderRadius: "4px",
    padding: "5px 15px"
  },
  comments: {
    width: "100%",
    backgroundColor: "#fff"
  }
});

class ShareWithOthers extends React.Component {
  state = {
    email: ""
  };
  emailHandler = event => {
    this.setState({ email: event.target.value });
  };
  optionalTextHandler = event => {
    this.setState({ optionalText: event.target.value });
  };
  submitRequest = () => {
    let initials = this.state.email.split(",");
    let optionalText = this.state.optionalText;
    for (let initial of initials) {
      initial = initial.trim();
      const obj = {
        commentValue: "@" + initial,
        commentStatus: "",
        percolateId: this.props.assignment.id,
        replyToId: 0,
        userInitials: this.props.name,
        optionalText: optionalText,
        assignmentName: this.props.assignment.name
      };
      this.props.shareUrlToOther(obj);
      this.props.addCollaborator &&
        this.props.addCollaborator({
          userInitials: initial
        });
    }
    this.props.handleClose();
  };
  render() {
    const { handleClose, classes } = this.props;
    return (
      <Dialog
        open={true}
        onClose={handleClose}
        aria-labelledby="form-dialog-title"
        classes={{ paperScrollPaper: classes.dialogContainer }}
      >
        <Typography variant="title" className={classes.title}>
          <span>Share</span>
        </Typography>
        <DialogContent className={classes.dialogContent}>
          <div className={classes.to}>
            Send to (Use the initials of team members and separate by commas)
          </div>
          <div>
            <Input
              className={classes.email}
              value={this.state.email}
              onChange={this.emailHandler}
            />
          </div>
          <div className={classes.to}>Comments(optional)</div>
          <div>
            <TextField
              id="outlined-bare"
              className={classes.comments}
              margin="normal"
              multiline
              rows="4"
              variant="outlined"
              inputProps={{ "aria-label": "bare" }}
              onChange={this.optionalTextHandler}
            />
          </div>
          <Card
            {...this.props}
            email={this.state.email}
            submitRequest={this.submitRequest}
          />
        </DialogContent>
      </Dialog>
    );
  }
}

export default withStyles(styles)(ShareWithOthers);
