import React, { Fragment } from "react";
import {
  withStyles,
  Dialog,
  TextField,
  Typography,
  Button
} from "@material-ui/core";
import IconButton from "@material-ui/core/IconButton";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import CloseIcon from "@material-ui/icons/Close";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogActions from "@material-ui/core/DialogActions";

const styles = theme => ({
  minWidth: {
    width: "100%"
  },
  paperScrollPaper: {
    maxHeight: 375,
    maxWidth: 729,
    height: 375,
    width: 729
  },
  messageWrapper: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center"
  },
  messageHeader: {
    textAlign: "center",
    fontSize: "25px",
    fontWeight: "600",
    color: "#005f9e"
  },
  messageDesc: {
    textAlign: "center",
    color: "#005f9e",
    fontSize: "15px",
    fontWeight: "200"
  },
  button2: {
    backgroundColor: "#005f9e",
    color: "#fff !important",
    "&:hover": {
      backgroundColor: "#005f9e",
      color: "#fff !important"
    }
  },
  disabled: {
    backgroundColor: "#cccccc"
  },
  button: {
    backgroundColor: "#005f9e",
    color: "#fff !important",
    "&:hover": {
      backgroundColor: "#005f9e",
      color: "#fff !important"
    }
  },
  button1: {
    border: "solid 2px #005f9e",
    color: "#005f9e",
    marginRight: "1em",
    "&:hover": {
      border: "solid 2px #005f9e",
      color: "#005f9e"
    },
    message: {
      fontSize: "16px",
      fontWeight: "normal",
      fontStyle: "normal",
      fontStretch: "normal",
      lineHeight: " normal",
      letterSpacing: "normal",
      textAlign: "center",
      color: " #000000"
    }
  }
});

const DialogTitle = withStyles(theme => ({
  root: {
    borderBottom: `1px solid ${theme.palette.divider}`,
    margin: 0,
    padding: theme.spacing.unit * 2,
    backgroundColor: " #e5e5e5"
  },
  header: {
    fontFamily: "AvenirNextLT-Demi",
    fontSize: "18px",
    fontWeight: "600",
    fontStyle: "normal",
    fontStretch: "normal",
    lineHeight: "normal",
    letterSpacing: "normal",
    color: " #000000"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing.unit,
    top: theme.spacing.unit,
    color: theme.palette.grey[500]
  }
}))(props => {
  const { children, classes, onClose } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root}>
      <Typography variant="subtitle1" className={classes.header}>
        {children}
      </Typography>
      {onClose ? (
        <IconButton
          aria-label="Close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles(theme => ({
  root: {
    margin: 0,
    padding: theme.spacing.unit * 2
  }
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
  root: {
    borderTop: `1px solid ${theme.palette.divider}`,
    margin: 0,
    padding: theme.spacing.unit,
    backgroundColor: "#e5e5e5"
  }
}))(MuiDialogActions);

const CustomizedDialogDemo = ({
  open,
  classes,
  onClose,
  handleChange,
  feedback,
  onSubmit,
  isDone
}) => {
  return (
    <div>
      <Dialog
        onClose={onClose}
        aria-labelledby="customized-dialog-title"
        open={open}
        classes={{ paperScrollPaper: classes.paperScrollPaper }}
      >
        <DialogTitle id="customized-dialog-title" onClose={onClose}>
          Feedback
        </DialogTitle>
        <DialogContent>
          {isDone ? (
            <div className={classes.minWidth + " " + classes.messageWrapper}>
              <Typography
                component="h4"
                variant="h2"
                className={classes.messageHeader}
              >
                Thanks!
              </Typography>
              <Typography className={classes.messageDesc}>
                We appreciate the feedback.
              </Typography>
            </div>
          ) : (
            <Fragment>
              <Typography className={classes.message}>
                Your feedback along with your initials will be sent to our team.
              </Typography>
              <TextField
                id="outlined-multiline-flexible"
                multiline
                rows="10"
                value={feedback}
                onChange={handleChange}
                fullWidth={true}
                variant="standard"
              />
            </Fragment>
          )}
        </DialogContent>
        <DialogActions>
          {isDone ? (
            <Button onClick={onClose} className={classes.button}>
              Close
            </Button>
          ) : (
            <Fragment>
              <Button onClick={onClose} className={classes.button1}>
                CANCEL
              </Button>
              <Button
                onClick={onSubmit}
                className={classes.button2}
                classes={{ disabled: classes.disabled }}
                disabled={!feedback}
              >
                SUBMIT
              </Button>
            </Fragment>
          )}
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default withStyles(styles)(CustomizedDialogDemo);
