import {
  Button,
  Paper,
  Table,
  TableBody,
  TableHead,
  TableRow,
  Typography,
  withStyles
} from "@material-ui/core";
import Delete from "@material-ui/icons/DeleteOutline";
import CWBDialog from "../Dialog/CWBDialog";
import * as R from "ramda";
import React from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import CustomTableCell from "./CustomTableCell";
import {
  deleteProjectRequest,
  shareRelatedProjects
} from "../../redux/actions/commentAction";
import ArrowDown from "@material-ui/icons/KeyboardArrowDown";
import DateDropDown from "./DateDropDown";

const style = theme => ({
  root: {
    paperbox: {
      margin: `${theme.spacing.unit}px auto`
    },
    contentHeading: {
      backgroundImage: "linear-gradient(275deg, #008eaad9, #00aea9d6)",
      padding: "0.6rem 1rem",
      borderRadius: "2px",
      fontSize: "1rem",
      fontWeight: 900,
      color: "#fff"
    }
  },
  noProject: {
    padding: "15px",
    fontSize: "1.2rem"
  },
  projectViewMore: {
    padding: "15px 0px",
    textAlign: "center",
    backgroundColor: "#f2f2f2",
    color: "#005f9e",
    fontWeight: "bold"
  },
  deleteIcon: {
    color: "#005f9e"
  },
  regularFont: {
    fontFamily: "AvenirNextLT-Regular !important"
  }
});

class RelatedProject extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showAllProjects: false,
      commentId: null,
      showDeleteDialog: false,
      sortField: "updatedAt",
      sortOrder: "desc"
    };
  }
  componentDidMount() {
    const { userID, shareRelatedProjects } = this.props;
    shareRelatedProjects(userID);
  }
  DeleteProject(commentId) {
    this.setState({ showDeleteDialog: true, commentId });
  }

  sort = (sortField, sortOrder) => {
    this.setState({ sortField, sortOrder });
  };

  onClose = confirm => {
    if (confirm === "yes") {
      this.props.deleteProjectRequest({ commentId: this.state.commentId });
    }
    this.setState({ showDeleteDialog: false, commentId: null });
  };
  render() {
    let {
      classes,
      projects,
      className,
      isFetching,
      renderDate,
      searchTxt
    } = this.props;
    const { showAllProjects, sortField, sortOrder } = this.state;

    projects = R.uniqBy(function(item) {
      return item.percolateId;
    }, projects);

    if (sortField === "updatedAt") {
      projects = projects.sort((a, b) => {
        const date1 = a.updatedAt ? new Date(a.updatedAt).getTime() : 10;
        const date2 = b.updatedAt ? new Date(b.updatedAt).getTime() : 10;
        return sortOrder === "desc" ? date2 - date1 : date1 - date2;
      });
    }

    if (sortField === "userInitials") {
      projects = projects.sort((a, b) => {
        const str1 = a.userInitials ? a.userInitials.trim().toLowerCase() : "";
        const str2 = b.userInitials ? b.userInitials.trim().toLowerCase() : "";
        return sortOrder === "desc"
          ? str2.localeCompare(str1)
          : str1.localeCompare(str2);
      });
    }

    if (searchTxt) {
      projects = projects.filter(project => {
        if (
          project &&
          project.assignmentName &&
          project.assignmentName.toLowerCase().includes(searchTxt.toLowerCase())
        ) {
          return true;
        }
        return false;
      });
    }

    const totalProjects = projects.length;
    if (!showAllProjects) {
      projects = projects.slice(0, 10);
    }

    const renderProjects =
      projects && projects.length ? (
        <div>
          <CWBDialog
            open={this.state.showDeleteDialog}
            onClose={this.onClose}
            confirmation={true}
            message={`Remove this project? <br /><br />`}
            customClass={`delete-dialog`}
          />
          <Table className={classes.table}>
            <TableHead className={className}>
              <TableRow className={"table-headers-row"}>
                <CustomTableCell>NAME</CustomTableCell>
                <CustomTableCell>
                  <DateDropDown sort={this.sort} />
                </CustomTableCell>
                <CustomTableCell>
                  <DateDropDown
                    title="OWNER"
                    sortField="userInitials"
                    sort={this.sort}
                    options={[
                      { title: "Ascending", value: "asc" },
                      { title: "Descending", value: "desc" }
                    ]}
                  />
                </CustomTableCell>
                <CustomTableCell align="right" />
              </TableRow>
            </TableHead>
            <TableBody>
              {projects.map(project => (
                <TableRow
                  key={project.commentId}
                  className={"dashboard-table-row"}
                >
                  <CustomTableCell component="td" scope="row">
                    <Link
                      to={
                        "/" +
                        project.percolateId +
                        (project.percolateId.length > 13
                          ? "?unlinked=true"
                          : "")
                      }
                    >
                      {project.assignmentName}
                      {project.userId}
                    </Link>
                  </CustomTableCell>
                  <CustomTableCell
                    component="td"
                    scope="row"
                    className={classes.regularFont}
                  >
                    {renderDate(project)}
                  </CustomTableCell>
                  <CustomTableCell
                    component="td"
                    scope="row"
                    className={classes.regularFont}
                  >
                    {project.userInitials}
                  </CustomTableCell>
                  <CustomTableCell align="right" className="delete-icon-cell">
                    <Button
                      size="small"
                      onClick={() => this.DeleteProject(project.commentId)}
                    >
                      <Delete className={classes.deleteIcon} />
                    </Button>
                  </CustomTableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className={classes.noProject}>None</div>
      );

    return (
      <Paper className={classes.paperbox + " project-collab"}>
        <Typography variant="title" className={"mod-header"}>
          Projects I’m collaborating on
        </Typography>
        {!isFetching ? <div>{renderProjects}</div> : null}
        {!showAllProjects && totalProjects > 10 ? (
          <div
            className={classes.projectViewMore}
            onClick={() => this.setState({ showAllProjects: true })}
          >
            VIEW MORE PROJECTS
            <br />
            <ArrowDown />
          </div>
        ) : null}
      </Paper>
    );
  }
}

const mapStateToProps = state => {
  return {
    projects: state.comment.relatedProject,
    isFetching: state.comment.isFetching
  };
};

export default connect(
  mapStateToProps,
  { shareRelatedProjects, deleteProjectRequest }
)(withStyles(style)(RelatedProject));
