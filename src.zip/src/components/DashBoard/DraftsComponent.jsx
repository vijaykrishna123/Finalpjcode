import {
  Button,
  Grid,
  Paper,
  Table,
  TableBody,
  TableHead,
  TableRow,
  Typography,
  Dialog,
  DialogContent,
  FormControlLabel,
  Checkbox
} from "@material-ui/core";
import React, { useState } from "react";
import * as R from "ramda";
import { Link } from "react-router-dom";
import Delete from "@material-ui/icons/DeleteOutline";
import CustomTableCell from "./CustomTableCell";
import CWBDialog from "../Dialog/CWBDialog";

function DraftsComponent(props) {
  const [indexToBeDeleted, setIndexToBeDeleted] = useState("");
  const [draftToBeLinked, setDraftToLinked] = useState({});
  const [assignmentId, setAssignmentId] = useState("");
  const [error, setError] = useState("");
  const {
    classes,
    drafts,
    deleteDraft,
    allAssignments,
    renderDate,
    linkDraftToAssignment,
    userDetails
  } = props;
  if (!drafts || !drafts.length) {
    return null;
  }
  const onDeletedDialogClose = confirm => {
    if (confirm === "yes") {
      deleteDraft({ id: indexToBeDeleted });
    }
    setIndexToBeDeleted("");
  };

  const assignmentHandler = event => {
    setAssignmentId(event.target.value);
  };

  const onCloseLinkDialog = () => {
    setDraftToLinked({});
    setAssignmentId("");
    setError("");
  };

  const linkDraftToAssignmentSubmit = () => {
    if (!assignmentId) {
      setError("Please select the assignment");
      return;
    }
    linkDraftToAssignment({
      assignmentId: assignmentId,
      draftId: draftToBeLinked.id,
      userInitials: userDetails ? userDetails.userId : ""
    });
    onCloseLinkDialog();
  };

  const renderProjects = () => {
    if (R.isEmpty(allAssignments) || R.isEmpty(allAssignments.assignments)) {
      return null;
    }
    const assignments = Object.keys(allAssignments.assignments)
      .map(assignment => allAssignments.assignments[assignment])
      .filter(assignment => assignment.template === draftToBeLinked.template);
    return (
      <Paper className={classes.paperbox}>
        <Table className={classes.table}>
          <TableHead className={classes.contentHeading}>
            <TableRow>
              <CustomTableCell component="th" scope="row">
                CONTENT
              </CustomTableCell>
              <CustomTableCell align="right" className={classes.alignRight}>
                DATE
              </CustomTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {assignments.map((assignment, index) => {
              return (
                <TableRow className={"dashboard-table-row"} key={index}>
                  <CustomTableCell component="th" scope="row">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={assignmentId === assignment.id}
                          onChange={assignmentHandler}
                          value={assignment.id}
                          color="primary"
                        />
                      }
                      label={assignment.title}
                    />
                  </CustomTableCell>
                  <CustomTableCell align="right">
                    {renderDate(assignment)}
                  </CustomTableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Paper>
    );
  };
  return (
    <Grid item xs={12}>
      <CWBDialog
        open={indexToBeDeleted}
        onClose={onDeletedDialogClose}
        confirmation={true}
        message={`Remove this draft?<br /><br />`}
        customClass={`delete-dialog`}
      />

      <Dialog open={!!draftToBeLinked.id}>
        <DialogContent className={classes.dialogContent}>
          <h2>Select project to link "{draftToBeLinked.name}"</h2>
          {renderProjects()}
          <br />
          {error ? <div className={classes.error}>{error}</div> : null}
          <br />
          <Button variant="outlined" onClick={onCloseLinkDialog}>
            CANCEL
          </Button>
          <Button
            variant="contained"
            className={classes.button}
            onClick={linkDraftToAssignmentSubmit}
          >
            LINK
          </Button>
        </DialogContent>
      </Dialog>

      <Paper className={classes.paperbox}>
        <Typography variant="title" className={"mod-header"}>
          Drafts
        </Typography>
        <Table className={classes.table}>
          <TableHead className={classes.contentHeading}>
            <TableRow>
              <CustomTableCell component="th" scope="row">
                Name
              </CustomTableCell>
              <CustomTableCell align="right" className={classes.alignRight}>
                Type
              </CustomTableCell>
              <CustomTableCell align="right"></CustomTableCell>
              <CustomTableCell align="right" />
            </TableRow>
          </TableHead>
          <TableBody>
            {drafts.map((draft, index) => {
              return (
                <TableRow className={"dashboard-table-row"} key={index}>
                  <CustomTableCell component="td" scope="row">
                    {draft.name}
                  </CustomTableCell>
                  <CustomTableCell
                    align="right"
                    className={classes.alignRight}
                    component="td"
                    scope="row"
                  >
                    {draft.template}
                  </CustomTableCell>
                  <CustomTableCell
                    align="right"
                    component="td"
                    scope="row"
                    className={classes.alignRight}
                  >
                    <Delete onClick={event => setIndexToBeDeleted(draft.id)} />
                  </CustomTableCell>
                  <CustomTableCell align="right" className={classes.alignRight}>
                    <Button
                      component={Link}
                      to={`/${draft.id}?unlinked=true`}
                      size="small"
                      className={`btn-large btn-solid-blue ${classes.draftBtn}`}
                    >
                      VIEW
                    </Button>
                    <Button
                      size="small"
                      className={"btn-large btn-solid-blue"}
                      onClick={event => setDraftToLinked(draft)}
                    >
                      LINK PROJECT
                    </Button>
                  </CustomTableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Paper>
    </Grid>
  );
}

export default DraftsComponent;
