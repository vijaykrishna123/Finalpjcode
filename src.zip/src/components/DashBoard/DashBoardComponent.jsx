import PropTypes from "prop-types";
import React, { useState } from "react";
import { withStyles } from "@material-ui/core/styles";
import {
  Button,
  Grid,
  Paper,
  Table,
  TableBody,
  TableHead,
  TableRow,
  Toolbar,
  Typography,
  TextField
} from "@material-ui/core";
import { Link } from "react-router-dom";
import { withRouter } from "react-router";
import AddIcon from "@material-ui/icons/AddCircle";
import ArrowDown from "@material-ui/icons/KeyboardArrowDown";
import Delete from "@material-ui/icons/DeleteOutline";
import Moment from "moment";
import * as R from "ramda";
import ReactLoading from "react-loading";
import CustomTableCell from "./CustomTableCell";
import RelatedProject from "./RelatedProject";
import VersionTool from "./VersionTool";
import RenderToBeLinkedProjects from "./RenderToBeLinkedProjects";
import DateDropDown from "./DateDropDown";
import TemplateDropDown from "./TemplateDropDown";
import States from "./States";
import {
  CreatingDraft,
  RemoveDrafts,
  DraftRemoving,
  LinkConfirmation,
  StateChangeDialog,
  LinkedProjectSuccess,
  LinkDraft,
  CreateDraft
} from "./DashBoardDialogs";

const styles = theme => ({
  root: {
    flexGrow: 1
  },
  button: {
    margin: 0,
    backgroundColor: "#005f9e",
    color: "#fff",
    "&:hover": {
      backgroundColor: "#005f9e"
    }
  },
  confirmationDialog: {
    padding: "40px 80px 20px !important"
  },
  confirmationContent: {
    maxWidth: "300px",
    textAlign: "center"
  },
  confirmationActions: {
    paddingBottom: "10px",
    justifyContent: "center"
  },
  buttonOutlined: {
    color: "#005f9e",
    border: "2px solid #005f9e",
    backgroundColor: "#fff"
  },
  createBtn: {
    backgroundColor: "transparent",
    "&:hover": {
      backgroundColor: "transparent"
    }
  },
  projectViewMore: {
    padding: "15px 0px",
    textAlign: "center",
    backgroundColor: "#f2f2f2",
    color: "#005f9e",
    fontWeight: "bold"
  },
  addBtn: {
    marginRight: "5px"
  },
  input: {
    width: "100%",
    backgroundColor: "#ffffff",
    fontSize: "24px",
    padding: "4px 4px 4px 7px",
    borderRadius: "4px"
  },
  contentHeading: {
    backgroundImage: "linear-gradient(275deg, #008eaad9, #00aea9d6)",
    padding: "0.6rem 1rem",
    borderRadius: "2px",
    fontSize: "1rem",
    fontWeight: 900,
    color: "#fff"
  },
  statusCol: {
    textAlign: "center !important"
  },
  paper: {
    maxWidth: 1000,
    margin: `${theme.spacing.unit}px auto`,
    padding: theme.spacing.unit * 4
  },
  paperbox: {},
  paperboxLinkTemplates: {
    maxHeight: "450px",
    overflowY: "auto"
  },
  deleteCell: {
    padding: "10px",
    width: "20px"
  },
  checkboxCellHeader: {
    paddingLeft: "40px"
  },
  linkCell: {
    width: "165px"
  },
  image: {
    width: "56px",
    height: "55px",
    objectFit: "contain"
  },
  dialogTitle: {
    backgroundColor: "#eee",
    fontSize: "18px"
  },
  loadingContent: {
    padding: "120px 150px !important",
    textAlign: "center"
  },
  linkedDialogSuccess: {
    padding: "50px 100px 40px !important",
    textAlign: "center"
  },
  linkedIcon: {
    fontSize: "40px",
    color: "green"
  },
  loadingContainer: {
    textAlign: "center",
    marginBottom: "10px"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing.unit,
    top: theme.spacing.unit,
    color: theme.palette.grey[500]
  },
  stateChangeBtn: {
    padding: "7px 40px"
  },
  DialogActions: {
    float: "right"
  },
  createDraftBtn: {
    margin: 0
  },
  DialogContent: {
    padding: "30px"
  },
  createDialogContent: {
    padding: "20px",
    minWidth: "400px"
  },
  alignRight: {
    textAlign: "right !important"
  },
  header: {
    display: "flex",
    justifyContent: "space-between"
  },
  error: {
    color: "red"
  },
  checkbox: {
    margin: "0px"
  },
  marginRight10: {
    marginRight: "10px"
  },
  deleteIcon: {
    color: "#005f9e"
  },
  searchContainer: {
    marginBottom: "16px"
  },
  disabled: {
    backgroundColor: "#cccccc"
  },
  dropdownPaper: {
    position: "absolute",
    padding: 0
  }
});

function DashBoard(props) {
  const [open, setOpen] = useState(false);
  const [templateType, setTemplateType] = useState("");

  const [showAllProjects, setShowAllProjects] = useState(false);
  const [assignmentToStateChange, setAssignmentToStateChange] = useState({});
  const [stateChangeMesssage, setStateChangeMesssage] = useState("");
  const [nextState, setNextState] = useState("");

  const [draftToBeLinked, setDraftToLinked] = useState({});
  const [assignmentId, setAssignmentId] = useState("");
  const [searchTxt, setSearchTxt] = useState("");

  const [indexToBeDeleted, setIndexToBeDeleted] = useState("");
  const [type, setType] = useState("Email");
  const [name, setName] = useState("");
  const [formError, setFormError] = useState("");

  const [sortField, setSortField] = useState("updatedAt");
  const [sortOrder, setSortOrder] = useState("desc");
  const [transferZip, setTransferZip] = useState(true);

  const {
    draftCreating,
    linkingStatus,
    allAssignments,
    loading,
    error,
    userDetails,
    templates,
    states,
    drafts,
    addDraft,
    deleteDraft,
    setLinkingStatus,
    linkDraftToAssignment,
    changeState,
    uploadTransferZip
  } = props.assignments;
  const { classes } = props;

  let allProjects = [];
  if (allAssignments && allAssignments.assignments) {
    allProjects = Object.keys(allAssignments.assignments).map(
      assignment => allAssignments.assignments[assignment]
    );
    drafts.forEach(draft => {
      if (draft) {
        draft.title = draft.name;
        draft.updatedAt = draft.updatedAt || draft.createdAt;
        draft.isDraft = true;
      }
    });
    allProjects = allProjects.concat(drafts);
  }

  const onCloseLinkDialog = () => {
    setDraftToLinked({});
    setAssignmentId("");
  };

  const assignmentHandler = event => {
    if (assignmentId && assignmentId === event.target.value) {
      return setAssignmentId("");
    }
    setAssignmentId(event.target.value);
  };

  const handleStateChange = (assignment, e) => {
    const nextState = e.target.value;
    if (assignment.stateName === nextState) return;
    const state = states.filter(s => s.stateName === nextState)[0];
    let message = `You are transitioning from ${assignment.stateName} to ${nextState}`;
    if (state.id === 4) {
      message =
        "You are marking this project as complete. You’ll still be able to go back and make changes if needed.";
    }
    setStateChangeMesssage(message);
    setAssignmentToStateChange(assignment);
    setNextState(nextState);
  };

  const onStateChangeConfirmation = status => {
    if (status === "Yes") {
      const state = states.filter(s => s.stateName === nextState)[0];

      console.log("assignmentToStateChange>>>>>", assignmentToStateChange);

      changeState({
        assignmentId: assignmentToStateChange.id,
        stateName: nextState,
        stateId: state ? state.id : ""
      });
      if (transferZip) {
        const payload = {
          id: assignmentToStateChange.id,
          newVersion: false,
          referenceNumber: assignmentToStateChange.referenceNumber,
          pdfCategory: "FILING_ZIP",
          workfrontDocName: assignmentToStateChange.title
        };
        uploadTransferZip(payload);
      }
    }
    setAssignmentToStateChange({});
    setStateChangeMesssage("");
    setNextState("");
  };

  const onTransferZipChange = e => {
    console.log(">>>e", e.target.checked);
    setTransferZip(e.target.checked);
  };

  const onLinkConfirmation = status => {
    if (status === "Yes") {
      const assignment = allProjects.filter(ass => ass.id === assignmentId)[0];
      linkDraftToAssignment({
        assignmentName: assignment ? assignment.title : "",
        assignmentId: assignmentId,
        draftId: draftToBeLinked.id,
        userInitials: userDetails ? userDetails.userId : ""
      });
    } else {
      setAssignmentId("");
      setLinkingStatus({ status: "" });
    }
    setDraftToLinked({});
  };

  const linkDraftToAssignmentSubmit = () => {
    if (!assignmentId) return;
    setLinkingStatus({ status: "confirmation" });
  };

  const nameHandler = event => {
    setName(event.target.value);
  };

  const typeHandler = event => {
    setType(event.target.value);
  };

  const onDeletedDialogClose = confirm => {
    if (confirm === "yes") {
      deleteDraft({ id: indexToBeDeleted });
    }
    setIndexToBeDeleted("");
  };

  const onCreateDraftDialogClose = () => {
    setOpen(false);
    setType("Email");
    setFormError("");
    setName("");
  };

  const renderDate = assignment => {
    return Moment(assignment.updatedAt).isValid()
      ? Moment(assignment.updatedAt).format("MM/DD/YYYY")
      : "TBD";
  };

  const createDraft = event => {
    event.preventDefault();
    if (!name || !name.trim()) {
      return setFormError("Name is Required");
    }
    addDraft({
      assignmentName: name,
      templateName: type,
      userInitials: userDetails.userId,
      unlinkedAssignment: true
    });
    onCreateDraftDialogClose();
  };

  const handleSearchInput = event => {
    setSearchTxt(event.target.value);
  };

  const renderToBeLinkedProjects = () => {
    if (R.isEmpty(allAssignments) || R.isEmpty(allAssignments.assignments))
      return null;
    let assignments = Object.keys(allAssignments.assignments)
      .map(assignment => allAssignments.assignments[assignment])
      .filter(assignment => assignment.template === draftToBeLinked.template);
    return (
      <RenderToBeLinkedProjects
        classes={classes}
        assignments={assignments}
        assignmentId={assignmentId}
        assignmentHandler={assignmentHandler}
        renderDate={renderDate}
        sortByDate={sortByDate}
      />
    );
  };

  const onLinkedClose = () => {
    setLinkingStatus({ status: "" });
    setDraftToLinked({});
    setAssignmentId("");
  };

  const goto = () => {
    const newpath = `/${assignmentId}`;
    onLinkedClose();
    props.history.push(newpath);
  };

  const sort = (field, sortOrder) => {
    setSortOrder(sortOrder);
    setSortField(field);
  };

  const sortByDate = (allProjects, sortOrder) => {
    return allProjects.sort((a, b) => {
      const date1 = a.updatedAt ? new Date(a.updatedAt).getTime() : 10;
      const date2 = b.updatedAt ? new Date(b.updatedAt).getTime() : 10;
      return sortOrder === "desc" ? date2 - date1 : date1 - date2;
    });
  };

  if (loading) return <ReactLoading type={"bubbles"} color={"#000000"} />;
  if (R.isEmpty(allAssignments)) return null;

  if (sortField === "updatedAt") {
    allProjects = sortByDate(allProjects, sortOrder);
  }

  if (sortField === "template") {
    allProjects = allProjects.sort((a, b) => {
      const str1 = a.template ? a.template.toLowerCase() : "";
      const str2 = b.template ? b.template.toLowerCase() : "";
      return sortOrder === "desc"
        ? str2.localeCompare(str1)
        : str1.localeCompare(str2);
    });
  }

  if (templateType) {
    allProjects = allProjects.filter(
      project => project.template === templateType
    );
  }

  if (searchTxt) {
    allProjects = allProjects.filter(
      project =>
        project &&
        project.title &&
        project.title.toLowerCase().includes(searchTxt.toLowerCase())
    );
  }
  const totalProjects = allProjects.length;
  if (!showAllProjects) allProjects = allProjects.slice(0, 10);

  return (
    <main>
      <div className={classes.root}>
        <RemoveDrafts
          open={!!indexToBeDeleted}
          onClose={onDeletedDialogClose}
        />
        <DraftRemoving open={linkingStatus === "creating"} classes={classes} />
        <LinkedProjectSuccess
          open={linkingStatus === "created"}
          classes={classes}
          onClose={onLinkedClose}
          onGoTo={goto}
        />
        <LinkDraft
          classes={classes}
          open={!!draftToBeLinked.id && linkingStatus !== "confirmation"}
          draftToBeLinked={draftToBeLinked}
          assignmentId={assignmentId}
          renderToBeLinkedProjects={renderToBeLinkedProjects}
          onLink={linkDraftToAssignmentSubmit}
          onClose={onCloseLinkDialog}
        />
        <LinkConfirmation
          classes={classes}
          open={linkingStatus === "confirmation"}
          onClose={onLinkConfirmation}
        />
        <StateChangeDialog
          classes={classes}
          open={!!nextState}
          message={stateChangeMesssage}
          onClose={onStateChangeConfirmation}
          showTransferZip={nextState === "COMPLETE"}
          transferZip={transferZip}
          onTransferZipChange={onTransferZipChange}
        />
        <Grid container justify="center" direction="row">
          <Toolbar className={"dashboard-header"}>
            <img src="./logomark.svg" alt="no logo" className={classes.image} />
            <Typography variant="title">Creative Workbench</Typography>
          </Toolbar>
        </Grid>
        <VersionTool />
        <Grid container justify="center" alignItems="flex-start" spacing={16}>
          <Grid item xs={12} className={classes.searchContainer}>
            <TextField
              InputProps={{
                disableUnderline: true,
                classes: { root: classes.input }
              }}
              className={classes.input}
              placeholder="Search by project name"
              onKeyUp={handleSearchInput}
              onChange={handleSearchInput}
              value={searchTxt}
            />
          </Grid>
          <Grid item xs={12}>
            <Grid
              container
              direction="row"
              justify="center"
              alignItems="flex-start"
              spacing={16}
            >
              <Grid item xs={7}>
                {R.isEmpty(allAssignments) ||
                R.isEmpty(allAssignments.assignments) ||
                error ? (
                  <Paper className={classes.paperbox}>
                    <Typography variant="title" className={"mod-header"}>
                      My projects
                    </Typography>
                    <Typography
                      variant="title"
                      style={{ margin: "1em", paddingBottom: "15px" }}
                    >
                      {error ? (
                        <span>
                          You are not assigned an account in Percolate
                        </span>
                      ) : (
                        <span>You have no assignments</span>
                      )}
                    </Typography>
                  </Paper>
                ) : (
                  <Paper className={classes.paperbox}>
                    <Typography
                      variant="title"
                      className={`mod-header ${classes.header}`}
                    >
                      My projects
                      <Button
                        className={
                          `${classes.button} ${classes.createBtn}` +
                          " create-draft-btn"
                        }
                        onClick={() => setOpen(true)}
                      >
                        <span className={classes.addBtn}>
                          <AddIcon />
                        </span>
                        CREATE DRAFT
                      </Button>
                    </Typography>
                    <CreatingDraft open={!!draftCreating} classes={classes} />
                    <CreateDraft
                      open={open}
                      classes={classes}
                      createDraft={createDraft}
                      name={name}
                      nameHandler={nameHandler}
                      formError={formError}
                      templates={templates}
                      type={type}
                      typeHandler={typeHandler}
                      onClose={onCreateDraftDialogClose}
                      onSubmit={createDraft}
                    />
                    <Table className={classes.table + " my-projects"}>
                      <TableHead className={classes.contentHeading}>
                        <TableRow className={"table-headers-row"}>
                          <CustomTableCell>NAME</CustomTableCell>
                          <CustomTableCell>
                            <DateDropDown sort={sort} />
                          </CustomTableCell>
                          <CustomTableCell>
                            <TemplateDropDown
                              templateType={templateType}
                              setTemplateType={setTemplateType}
                            />
                          </CustomTableCell>
                          <CustomTableCell></CustomTableCell>
                          <CustomTableCell className={classes.statusCol}>
                            STATUS
                          </CustomTableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {allProjects.map((assignment, index) => {
                          return (
                            <TableRow
                              className={"dashboard-table-row"}
                              key={index}
                            >
                              <CustomTableCell component="td" scope="row">
                                <Link
                                  to={`/${assignment.id}${
                                    assignment.isDraft ? "?unlinked=true" : ""
                                  }`}
                                >
                                  {assignment.title}
                                </Link>
                              </CustomTableCell>
                              <CustomTableCell>
                                {renderDate(assignment)}
                              </CustomTableCell>
                              <CustomTableCell>
                                {assignment.template}
                              </CustomTableCell>
                              <CustomTableCell
                                align="right"
                                className={classes.deleteCell}
                              >
                                {assignment.isDraft ? (
                                  <Delete
                                    className={classes.deleteIcon}
                                    onClick={event =>
                                      setIndexToBeDeleted(assignment.id)
                                    }
                                  />
                                ) : null}
                              </CustomTableCell>
                              <CustomTableCell
                                align="left"
                                className={classes.linkCell}
                              >
                                {assignment.isDraft ? (
                                  <Button
                                    size="small"
                                    className={
                                      "btn-large btn-solid-blue link-project-btn"
                                    }
                                    onClick={event =>
                                      setDraftToLinked(assignment)
                                    }
                                  >
                                    LINK PROJECT
                                  </Button>
                                ) : (
                                  <States
                                    states={states}
                                    assignment={assignment}
                                    handleStateChange={handleStateChange}
                                  />
                                )}
                              </CustomTableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>

                    {!showAllProjects && totalProjects > 10 ? (
                      <div
                        className={classes.projectViewMore}
                        onClick={() => setShowAllProjects(true)}
                      >
                        VIEW MORE PROJECTS <br />
                        <ArrowDown />
                      </div>
                    ) : null}
                  </Paper>
                )}
              </Grid>
              <Grid item xs={5}>
                {userDetails.userId && (
                  <RelatedProject
                    searchTxt={searchTxt}
                    renderDate={renderDate}
                    userID={userDetails.userId}
                    className={classes.contentHeading}
                  />
                )}
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </div>
    </main>
  );
}

DashBoard.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(withRouter(DashBoard));
