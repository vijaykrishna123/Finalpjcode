import React from "react";
import ArrowDown from "@material-ui/icons/KeyboardArrowDown";
import { withStyles, Select, MenuItem } from "@material-ui/core";

const styles = () => ({
  selectState: {
    borderRadius: "5px",
    border: "solid 1px #cccccc",
    backgroundColor: "#ffffff",
    padding: "5px 5px 5px 15px"
  },
  newState: {
    fontFamily: "AvenirNextLT-Demi",
    fontSize: "14px",
    color: "#b42573"
  }
});

function States(props) {
  const { classes, states, assignment, handleStateChange } = props;

  if (!assignment.stateName) {
    return <span className={classes.newState}>NEW!</span>;
  }
  const renderStates = () => {
    return states.map(state => {
      let activeState =
        assignment.stateId === 1 ? 2 : assignment.stateId === 4 ? 3 : "";
      if (
        !activeState &&
        assignment.workfrontDocsCount &&
        assignment.workfrontDocsCount !== "0"
      ) {
        activeState = 4;
      }
      if (!activeState && assignment.proofURL) {
        activeState = 3;
      }
      return (
        <MenuItem
          disabled={activeState !== state.id || assignment.stateId === state.id}
          key={state.id}
          value={state.stateName}
        >
          {state.stateName}
        </MenuItem>
      );
    });
  };
  return (
    <Select
      value={assignment.stateName}
      onChange={e => handleStateChange(assignment, e)}
      className={`selectState ${classes.selectState}`}
      IconComponent={ArrowDown}
    >
      >{renderStates()}
    </Select>
  );
}
export default withStyles(styles)(States);
