import React, { useState } from "react";
import { withStyles, Grid, Typography } from "@material-ui/core";
import cwbImg from "../../assets/images/VersionTool/cwb.png";
import discoverImg from "../../assets/images/VersionTool/discover.png";
import JulyPdf from "../../assets/pdf/CWB-update-07102019.pdf";
import SepPdf from "../../assets/pdf/CWB-update-09182019.pdf";
import NewVersionPdf from "../../assets/pdf/cwb-1.5-marquez.pdf";
import ViewPdf from "@material-ui/icons/FileCopy";

const styles = () => ({
  root: {
    backgroundColor: "rgba(0, 0, 0, 0.25)",
    padding: "2em 2em 1em 2em"
  },
  title: {
    display: "inline-block",
    fontSize: "14px",
    color: " #fff",
    fontWeight: "600"
  },
  image: {
    width: 255,
    height: 144,
    margin: "0 0 9 13px"
  },
  desc: {
    width: "91%",
    fontSize: 14,
    lineHeight: 1.89,
    fontWeight: "normal",
    color: "#fff",
    paddingLeft: "20px",
    marginTop: "10px"
  },
  action: {
    fontSize: "14px",
    textDecoration: "underline",
    cursor: "pointer",
    color: " #fff",
    fontWeight: 600,
    textAlign: "center",
    padding: "1em 1em 1em 1.5em",
    display: "inline-block"
  },
  viewPdf: {
    marginLeft: "5px",
    marginTop: "-2px",
    fontSize: "18px"
  },
  actionCenter: {
    textAlign: "center"
  },
  listName: {
    fontSize: "18px",
    lineHeight: "36px",
    color: "#fff",
    fontWeight: "bold"
  },
  listImage: {
    marginTop: "7px",
    float: "left",
    height: "24px",
    marginRight: "5px"
  },
  featureItem: {
    marginTop: "15px",
    color: "#fff"
  },
  listWrapper: {
    marginTop: "20px"
  },
  featureDetail: {
    margin: "5px",
    color: "#fff"
  },
  name: {
    padding: "0px 5px"
  },
  anchor: {
    color: "#fff",
    padding: "0px 5px",
    fontSize: "14px"
  },
  listitem: {
    margin: "5px 0px"
  }
});
function VersionTool(props) {
  const { classes } = props;

  const value = localStorage.getItem("showVersionTool");

  const [show, setShow] = useState(value !== "false");

  const showItem = () => {
    setShow(true);
    localStorage.setItem("showVersionTool", "true");
  };

  const hideItem = () => {
    setShow(false);
    localStorage.setItem("showVersionTool", "false");
  };
  const list = [
    {
      name: "Creative Workbench",
      image: cwbImg,
      items: [
        {
          title:
            "Proofing is live! Workfront’s proofing tool, ProofHQ, is now integrated with CWB",
          text:
            "Markup tools, preserved comments, versioning, and compare are all here. Generate proofs within CWB, add reviewers, and send custom notifications."
        },
        {
          title: "Redesigned and optimized dashboard",
          text:
            "Projects lists are now side-by-side for a better scan of workload, with the ability to quickly search and sort through projects."
        },
        {
          title:
            "Create drafts within CWB without waiting for a Percolate assignment",
          text:
            "If you want to get a jump start on an assignment even before it’s been assigned to you in Percolate, you can now do so in CWB. Once the Percolate project is assigned, you can link your draft to it."
        },
        {
          title: "Improvements to writing module",
          text:
            "You can now upload multiple backups at once, and attach responsive images to your project. A new list view makes it easier to maintain and scan. Automatic standard disclosures will also be populated into the template."
        }
      ]
    },
    {
      name: "Discover",
      image: discoverImg,
      items: [
        {
          title: "Discover Search improvements",
          text:
            "Adjusting filters dynamically update your search results, without the need to click a button."
        }
      ]
    }
  ];

  return (
    <Grid className={classes.root + " version-tool"}>
      <Grid
        container
        direction="row"
        justify="center"
        alignItems="flex-start"
        spacing={16}
      >
        <Grid item xs={12}>
          <Typography variant="title" className={"mod-header2"}>
            What's new?
            {!show && (
              <span className={`${classes.action}`} onClick={showItem}>
                SHOW ME
              </span>
            )}
            {show && (
              <span className={`${classes.action}`} onClick={hideItem}>
                HIDE ME
              </span>
            )}
          </Typography>
        </Grid>
        {show && (
          <Grid item xs={12}>
            <div className={classes.featureDetail}>
              <strong>CWB 1.5</strong>
              <span className={classes.name}>(Márquez)</span> |{" "}
              <a
                className={classes.anchor}
                href={NewVersionPdf}
                rel="noopener noreferrer"
                target="_blank"
              >
                VIEW PDF
              </a>
              <ViewPdf className={classes.viewPdf} />
            </div>

            <div className={classes.listWrapper}></div>
            {list.map((record, index) => (
              <div key={index}>
                <img
                  alt={record.name}
                  className={classes.listImage}
                  src={record.image}
                />
                <h4 className={classes.listName}>{record.name}</h4>
                <ul className={classes.featureItem}>
                  {record.items.map((item, index) => (
                    <li className={classes.listitem} key={index}>
                      <strong>{item.title} : </strong>
                      {item.text}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
            <div className={classes.featureDetail}>
              <strong>CWB 1.1</strong>
              <span className={classes.name}>(Melville)</span> |{" "}
              <a
                className={classes.anchor}
                href={SepPdf}
                rel="noopener noreferrer"
                target="_blank"
              >
                VIEW PDF
              </a>
              <ViewPdf className={classes.viewPdf} />
            </div>
            <div className={classes.featureDetail}>
              <strong>CWB 1.0</strong>
              <span className={classes.name}>(Morrison)</span> |{" "}
              <a
                className={classes.anchor}
                href={JulyPdf}
                rel="noopener noreferrer"
                target="_blank"
              >
                VIEW PDF
              </a>
              <ViewPdf className={classes.viewPdf} />
            </div>
          </Grid>
        )}
      </Grid>
    </Grid>
  );
}
export default withStyles(styles)(VersionTool);
