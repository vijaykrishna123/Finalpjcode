import ClassicEditorBase from "@ckeditor/ckeditor5-editor-classic/src/classiceditor";
import Autosave from "@ckeditor/ckeditor5-autosave/src/autosave";
import Essentials from "@ckeditor/ckeditor5-essentials/src/essentials";
import Alignment from "@ckeditor/ckeditor5-alignment/src/alignment";
import FontSize from "@ckeditor/ckeditor5-font/src/fontsize";
import FontFamily from "@ckeditor/ckeditor5-font/src/fontfamily";
import Autoformat from "@ckeditor/ckeditor5-autoformat/src/autoformat";
import Bold from "@ckeditor/ckeditor5-basic-styles/src/bold";
import Superscript from "@ckeditor/ckeditor5-basic-styles/src/superscript";
import Italic from "@ckeditor/ckeditor5-basic-styles/src/italic";
import BlockQuote from "@ckeditor/ckeditor5-block-quote/src/blockquote";
import EasyImage from "@ckeditor/ckeditor5-easy-image/src/easyimage";
import Heading from "@ckeditor/ckeditor5-heading/src/heading";
import Image from "@ckeditor/ckeditor5-image/src/image";
import ImageCaption from "@ckeditor/ckeditor5-image/src/imagecaption";
import ImageStyle from "@ckeditor/ckeditor5-image/src/imagestyle";
import ImageToolbar from "@ckeditor/ckeditor5-image/src/imagetoolbar";
import ImageUpload from "@ckeditor/ckeditor5-image/src/imageupload";
import Link from "@ckeditor/ckeditor5-link/src/link";
import List from "@ckeditor/ckeditor5-list/src/list";
import MediaEmbed from "@ckeditor/ckeditor5-media-embed/src/mediaembed";
import Paragraph from "@ckeditor/ckeditor5-paragraph/src/paragraph";
import PasteFromOffice from "@ckeditor/ckeditor5-paste-from-office/src/pastefromoffice";
import RealTimeCollaborativeComments from "@ckeditor/ckeditor5-real-time-collaboration/src/realtimecollaborativecomments";
import RealTimeCollaborativeTrackChanges from "@ckeditor/ckeditor5-real-time-collaboration/src/realtimecollaborativetrackchanges";
import PresenceList from "@ckeditor/ckeditor5-real-time-collaboration/src/presencelist";
import CustomFigureAttributes from "./CustomFigureAttributes";
import ImageTextAlternativeCustom from "./imagetextalternative";
import Table from "@ckeditor/ckeditor5-table/src/table";
import TableToolbar from "@ckeditor/ckeditor5-table/src/tabletoolbar";
import SpecialCharacterPlugin from "../../ckplugins/SpecialCharacterPlugin";
import CkEditorCloudUpload from "./s3uploadplugin/ckeditorcloudupload";

export default class ClassicEditor extends ClassicEditorBase {}

// Plugins to include in the build.
ClassicEditor.builtinPlugins = [
  Alignment,
  Autoformat,
  Autosave,
  BlockQuote,
  Bold,
  EasyImage,
  Essentials,
  FontFamily,
  FontSize,
  Heading,
  Image,
  ImageCaption,
  ImageTextAlternativeCustom,
  ImageStyle,
  ImageToolbar,
  ImageUpload,
  Italic,
  Link,
  List,
  MediaEmbed,
  Paragraph,
  PasteFromOffice,
  PresenceList,
  RealTimeCollaborativeComments,
  RealTimeCollaborativeTrackChanges,
  Superscript,
  Table,
  TableToolbar,
  CustomFigureAttributes,
  SpecialCharacterPlugin,
  CkEditorCloudUpload
];

// Editor configuration.
ClassicEditor.defaultConfig = {
  toolbar: {
    items: [
      "heading",
      "|",
      "fontsize",
      "fontfamily",
      "|",
      "bold",
      "italic",
      "link",
      "superscript",
      "|",
      "bulletedList",
      "numberedList",
      "|",
      "specialchars",
      "|",
      "blockquote",
      "insertTable",
      "mediaEmbed",
      "undo",
      "redo",
      "alignment",
      "imageUpload",
      "|",
      "comment",
      "|",
      "trackChanges"
    ]
  },
  fontSize: {
    options: [12, 14, "default", 18, 20, 22, 24, 26, 28, 30]
  },
  fontFamily: {
    options: ["default", "Arial, Helvetica, sans-serif", "AvenirNextLT-Regular"]
  },
  image: {
    styles: ["full", "alignLeft", "alignRight"],
    toolbar: [
      "imageStyle:alignLeft",
      "imageStyle:full",
      "imageStyle:alignRight",
      "|",
      "ImageTextAlternativeCustom"
    ]
  },
  table: {
    contentToolbar: ["tableColumn", "tableRow", "mergeTableCells"]
  },
  // This value must be kept in sync with the language defined in webpack.config.js.
  language: "en"
};
