import Plugin from "@ckeditor/ckeditor5-core/src/plugin";

/**
 * Plugin that converts custom attributes for elements that are wrapped in <figure> in the view.
 *
 * @extends module:core/plugin~Plugin
 */
export default class CustomFigureAttributes extends Plugin {
  init() {
    const editor = this.editor;
    const schema = editor.model.schema;
	const conversion = editor.conversion;

    // The 'customClass' attribute will store custom classes from data in the model so schema definitions to allow this attribute.
    schema.extend("image", { allowAttributes: ["customClass"] });
    schema.extend("table", { allowAttributes: ["customClass"] });
    schema.register( 'div', {
      allowWhere: '$block', // The div is allowed where any generic $block (ie paragraph) is allowed.
			allowContentOf: [ '$root' ], // Allow the content of $root, so any element that is allowed in root can also be inside div.
			allowAttributes: [ 'divId', 'divClasses' ] // Allow custom attributes.
		} );

    // Define upcast converters for <img> and <table> elements with "low" priority so they are run after default converters.
    conversion
      .for("upcast")
      .add(upcastCustomClasses("img"), { priority: "low" });
    conversion
      .for("upcast")
      .add(upcastCustomClasses("table"), { priority: "low" });

    // Define downcast converters for 'image' and 'table' model elements with "low" priority so they are run after default converters.
    conversion
      .for("downcast")
      .add(downcastCustomClasses("image", "img"), { priority: "low" });
    conversion
      .for("downcast")
      .add(downcastCustomClasses("table", "table"), { priority: "low" });

    // Define custom attributes that should be preserved.
    setupCustomAttributeConversion("img", "image", "id", editor);
    setupCustomAttributeConversion("table", "table", "id", editor);

		conversion.elementToElement( {
			model: 'div',
			view: 'div'
    } );
    // Add a two-way (view-to-model and model-to-view) converter for div id attribute.
		conversion.attributeToAttribute( {
			model: 'divId',
			view: {
				name: 'div',
				key: 'id'
			}
    } );
    // Add an upacast (view-to-model) converter for class attribute of a div.
		conversion.for( 'upcast' ).attributeToAttribute( {
			model: {
				key: 'divClasses',
				value: viewElement => viewElement.getAttribute( 'class' )
			},
			view: {
				name: 'div',
				key: 'class',
				value: /[\s\S]+/
			}
		} );

		// Add an downcast (model-to-view) converter for class attribute of a div.
		conversion.for( 'downcast' ).attributeToAttribute( {
			model: 'divClasses',
			view: 'class'
		} );
  }
}
function upcastCustomClasses(elementName) {
  return dispatcher =>
    dispatcher.on(`element:${elementName}`, (evt, data, conversionApi) => {
      const viewItem = data.viewItem;
      const modelRange = data.modelRange;
      const modelElement = modelRange && modelRange.start.nodeAfter;

      if (!modelElement) {
        return;
      }

      conversionApi.writer.setAttribute(
        "customClass",
        [...viewItem.getClassNames()],
        modelElement
      );
    });
}

/**
 * Creates downcast converter that add classes defined in `customClass` attribute to given view element.
 *
 * This converter expects that view element is nested in figure element.
 *
 * @param {String} modelElementName
 * @param {String} viewElementName
 * @returns {Function}
 */
function downcastCustomClasses(modelElementName, viewElementName) {
  return dispatcher =>
    dispatcher.on(`insert:${modelElementName}`, (evt, data, conversionApi) => {
      const modelElement = data.item;
      const viewFigure = conversionApi.mapper.toViewElement(modelElement);
      const viewElement = findViewChild(
        viewFigure,
        viewElementName,
        conversionApi
      );

      if (!viewElement) {
        return;
      }

      // The below code assumes that classes are set directly on <img> element.
      conversionApi.writer.addClass(
        modelElement.getAttribute("customClass"),
        viewElement
      );

      // If the classes should be passed to the <figure> use (instead of above):
      // conversionApi.writer.addClass( modelElement.getAttribute( 'customClass' ), viewFigure );
    });
}

/**
 * Helper method that search for given view element in all children of model element.
 *
 * @param {module:engine/view/item~Item} viewElement
 * @param {String} viewElementName
 * @param {module:engine/conversion/downcastdispatcher~DowncastConversionApi} conversionApi
 * @return {module:engine/view/item~Item}
 */
function findViewChild(viewElement, viewElementName, conversionApi) {
  const viewChildren = [
    ...conversionApi.writer.createRangeIn(viewElement).getItems()
  ];

  return viewChildren.find(item => item.is(viewElementName));
}

/**
 * Setups conversion for custom attribute on view elements contained inside figure.
 *
 * This method:
 *
 * - adds proper schema rules
 * - adds an upcast converter
 * - adds a downcast converter
 *
 * @param {String} viewElementName
 * @param {String} modelElementName
 * @param {String} viewAttribute
 * @param {module:core/editor/editor~Editor} editor
 */
function setupCustomAttributeConversion(
  viewElementName,
  modelElementName,
  viewAttribute,
  editor
) {
  // Extend schema to store attribute in the model.
  const modelAttribute = `custom-${viewAttribute}`;

  editor.model.schema.extend(modelElementName, {
    allowAttributes: [modelAttribute]
  });

  editor.conversion
    .for("upcast")
    .add(upcastAttribute(viewElementName, viewAttribute, modelAttribute));
    editor.conversion
    .for("downcast")
    .add(
      downcastAttribute(
        modelElementName,
        viewElementName,
        viewAttribute,
        modelAttribute
      )
    );
}

/**
 * Returns custom attribute upcast converter.
 *
 * @param {String} viewElementName
 * @param {String} viewAttribute
 * @param {String} modelAttribute
 * @returns {Function}
 */
function upcastAttribute(viewElementName, viewAttribute, modelAttribute) {
  return dispatcher =>
    dispatcher.on(`element:${viewElementName}`, (evt, data, conversionApi) => {
      const viewItem = data.viewItem;
      const modelRange = data.modelRange;
      const modelElement = modelRange && modelRange.start.nodeAfter;

      if (!modelElement) {
        return;
      }

      conversionApi.writer.setAttribute(
        modelAttribute,
        viewItem.getAttribute(viewAttribute),
        modelElement
      );
    });
}

/**
 * Returns custom attribute downcast converter.
 *
 * @param {String} modelElementName
 * @param {String} viewElementName
 * @param {String} viewAttribute
 * @param {String} modelAttribute
 * @returns {Function}
 */
function downcastAttribute(
  modelElementName,
  viewElementName,
  viewAttribute,
  modelAttribute
) {
  return dispatcher =>
    dispatcher.on(`insert:${modelElementName}`, (evt, data, conversionApi) => {
      const modelElement = data.item;
      const viewFigure = conversionApi.mapper.toViewElement(modelElement);
      const viewElement = findViewChild(
        viewFigure,
        viewElementName,
        conversionApi
      );

      if (!viewElement) {
        return;
      }

      conversionApi.writer.setAttribute(
        viewAttribute,
        modelElement.getAttribute(modelAttribute),
        viewElement
      );
    });
}
