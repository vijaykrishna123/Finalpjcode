import React, { Fragment, PureComponent } from "react";
import { withAuth } from "@okta/okta-react";
import TopBar from "./TopBar";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import {
  userErrorDetails,
  receiveUserDetails
} from "../../redux/actions/userActions";

class CWBHeader extends PureComponent {
  getCurrentUser = async () => {
    const user = await this.props.auth.getUser();
    await this.retrieveInitialFromName(user);
  };

  async componentDidMount() {
    setTimeout(() => this.getCurrentUser(), 3000);
  }

  retrieveInitialFromName = user => {
    if (null != user) {
      const { given_name, family_name, preferred_username, email } = user;
      const { receiveUserDetails } = this.props;
      let firstNameInitial = given_name.charAt(0);
      let lastNameInitial = family_name.charAt(0);
      let userInitials = {
        fullName: given_name + " " + family_name,
        initial: firstNameInitial + lastNameInitial,
        userId: preferred_username.split("@")[0],
        emailId: email
      };
      receiveUserDetails(userInitials);
    }
  };

  render() {
    return (
      <Fragment>
        <TopBar user={this.props} />
      </Fragment>
    );
  }
}

const mapStateToProps = ({ user, assignments, userAssignments }) => {
  return {
    user: user.user,
    error: user.error,
    assignment: assignments.assignment,
    loading: assignments.loading,
    dashBoardLoaded: userAssignments.dashBoardLoaded
  };
};

const mapDispatchToProps = dispatch => ({
  receiveUserDetails: user => dispatch(receiveUserDetails(user)),
  userErrorDetails: error => dispatch(userErrorDetails(error))
});

CWBHeader.propTypes = {
  userErrorDetails: PropTypes.func.isRequired,
  receiveUserDetails: PropTypes.func.isRequired
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withAuth(CWBHeader));
