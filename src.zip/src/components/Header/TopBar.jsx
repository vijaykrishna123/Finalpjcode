import AppBar from "@material-ui/core/AppBar";
import Fab from "@material-ui/core/Fab";
import Grid from "@material-ui/core/Grid";
import { withStyles } from "@material-ui/core/styles";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import classNames from "classnames";
import PropTypes from "prop-types";
import React, { Fragment } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { Link } from "react-router-dom";
import CWBTabs from "../Tabs/CWBTabs/Tabs";
import PageNameField from "./PageNameField";
import cwbImg from "../../assets/images/VersionTool/cwb.png";

const styles = theme => ({
  root: {
    flexGrow: 1
  },
  appBar: {
    left: "0px",
    backgroundColor: "#262d3a",
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    })
  },
  navButton: {
    margin: theme.spacing.unit,
    color: "#FFFFFF",
    fontSize: "12px",
    textTransform: "capitalize"
  },
  relative: {
    position: "relative"
  },
  fabButton: {
    margin: theme.spacing.unit,
    color: "#ffffff",
    backgroundColor: "#b42573",
    height: "32px",
    minWidth: "32px",
    width: "32px"
  },
  toolbar: {
    padding: "0 2em",
    marginLeft: "250px"
  },
  collapseToolbar: {
    marginLeft: "100px"
  },
  toolbarContainer: {
    width: "100%"
  },
  menuButton: {
    marginLeft: "40px !important",
    marginRight: 10
  },
  toolbarTitle: {
    flex: 1
  },
  disabledButton: {
    margin: theme.spacing.unit,
    backgroundColor: "#aab2b5 !important",
    color: "#fff !important"
  },
  button: {
    margin: theme.spacing.unit,
    backgroundColor: "#b42573",
    "&:hover": {
      backgroundColor: "#b42573"
    }
  },
  hide: {
    display: "none"
  },
  logo: {
    width: "30px",
    marginTop: "0",
    marginRight: "10px"
  }
});

class TopBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      collapse: false
    };
  }
  toggleCollapse = () => {
    const { collapse } = this.state;
    this.setState({ collapse: !collapse });
  };

  render() {
    const { user, dashBoardLoaded } = this.props.user;
    const { classes } = this.props;
    const { collapse } = this.state;

    return (
      <Fragment>
        <CWBTabs
          collapse={collapse}
          toggleCollapse={this.toggleCollapse}
          saveTheForm={this.saveTheForm}
          dashBoardLoaded={dashBoardLoaded}
        />
        <AppBar
          position="fixed"
          className={classNames(classes.appBar, classes.appBarShift)}
        >
          <Grid container direction="row">
            <Grid item lg={12} className={classes.toolbarContainer}>
              <Toolbar
                className={`${classes.toolbar} ${
                  collapse ? classes.collapseToolbar : ""
                }`}
              >
                <Typography
                  variant="subheading"
                  color="inherit"
                  style={{ marginRight: "auto" }}
                >
                  <img src={cwbImg} alt="no logo" className={classes.logo} />
                  <Link
                    to="/"
                    style={{ textDecoration: "none", color: "#fff" }}
                  >
                    Creative WorkBench
                  </Link>
                </Typography>
                <Typography
                  variant="subheading"
                  color="inherit"
                  noWrap
                  className={classes.toolbarTitle}
                >
                  <PageNameField assignmentDetails={this.props} />
                </Typography>
                <Fab size="small" className={classes.fabButton}>
                  {user}
                </Fab>
              </Toolbar>
            </Grid>
          </Grid>
        </AppBar>
      </Fragment>
    );
  }
}

TopBar.propTypes = { classes: PropTypes.object.isRequired };
const mapStateToProps = state => {
  return {
    write: state.write,
    comments: state.comment,
    assignments: state.assignments,
    userName: state.user.userId
  };
};
export default connect(
  mapStateToProps,
  null
)(withRouter(withStyles(styles)(TopBar)));
