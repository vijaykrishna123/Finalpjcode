import React from "react";
import { Toolbar, Typography } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";

import SearchIcon from "@material-ui/icons/Search";
import ResearchIcon from "@material-ui/icons/LocalLibraryOutlined";
import DoneIcon from "@material-ui/icons/Done";
import InfoIcon from "@material-ui/icons/InfoOutlined";
import CreateIcon from "@material-ui/icons/CreateOutlined";
import DashboardIcon from "@material-ui/icons/Dashboard";
import ListIcon from "@material-ui/icons/Link";

const isconList = {
  dashboard: <DashboardIcon />,
  list: <ListIcon />,
  research: <ResearchIcon />,
  create: <CreateIcon />,
  review: <DoneIcon />,
  search: <SearchIcon />,
  info: <InfoIcon />
};

const styles = () => ({
  container: {
    display: "flex",
    justifyContent: "space-between",
    margin: "15px 0px 35px"
  }
});

const Title = props => {
  const { icon, title, classes } = props;
  return (
    <Toolbar className={"tab-header " + classes.container}>
      <Typography variant="title">
        <div>
          {icon ? isconList[icon] : null}
          {title}
        </div>
      </Typography>
    </Toolbar>
  );
};

export default withStyles(styles)(Title);
