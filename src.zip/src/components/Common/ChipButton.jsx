import React from "react";
import CancelOutlined from "@material-ui/icons/CancelOutlined";
import { withStyles } from "@material-ui/core/styles";

const styles = theme => ({
  chipButton: {
    marginRight: "4px",
    color: "#005f9e !important",
    fontWeight: "bold",
    textTransform: "uppercase",
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important",
    background: "none",
    border: 0,
    padding: 0
  },
  cancelIcon: {
    cursor: "pointer",
    fontSize: "20px",
    marginBottom: "5px"
  }
});

const ChipButton = props => {
  const { chipButtonValues, onClose, classes } = props;

  const chipButtonValuesNew = chipButtonValues.filter(
    item => item && item.userInitials
  );
  return (
    <React.Fragment>
      {chipButtonValuesNew &&
        chipButtonValuesNew.map((item, index) => (
          <button
            key={index}
            id={item.userInitials}
            name={item.userInitials}
            color="primary"
            className={classes.chipButton}
          >
            {item.userInitials}
            <CancelOutlined
              className={classes.cancelIcon}
              onClick={() => onClose(item, index)}
            />
            ,
          </button>
        ))}
    </React.Fragment>
  );
};

export default withStyles(styles)(ChipButton);
