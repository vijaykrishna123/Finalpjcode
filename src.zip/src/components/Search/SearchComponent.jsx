import React from "react";
import SearchIcon from "@material-ui/icons/Search";
import {
  withStyles,
  Paper,
  IconButton,
  TextField,
  Select,
  Input,
  MenuItem
} from "@material-ui/core";
const styles = theme => {
  return {
    root: {
      flexDirection: "column",
      position: "relative"
    },
    input: {
      marginLeft: 8,
      flex: 1
    },
    iconButton: {
      padding: 10,
      color: "#00aea9"
    },
    divider: {
      width: 1,
      height: 28,
      margin: 4
    },
    width: {
      width: "100%"
    },
    autoComplete: {
      position: "absolute",
      zIndex: "99999",
      top: "3.3em"
    },
    flex: {
      display: "flex",
      padding: "2px 4px",
      alignItems: "center"
    },
    suggestionList: {
      padding: ".6em",
      cursor: "pointer"
    },
    clear: {
      color: "#47b1e9",
      cursor: "pointer",
      fontSize: "13px",
      fontWeight: "700"
    },
    wrapper: {
      backgroundImage:
        "linear-gradient(279deg, rgb(0, 142, 170), rgb(0, 174, 169))",
      padding: " 0 1em 1em 1em",
      width: "99.98%"
    }
  };
};
const SearchComponent = props => (
  <div className={props.classes.wrapper}>
    <Paper className={props.classes.root} elevation={1}>
      <div className={props.classes.width + " " + props.classes.flex}>
        <Select
          value={props.searchType}
          onChange={props.handleSearchTypeChange}
          input={<Input name="searchType" id="search-type" />}
          className={"keyword-select"}
        >
          <MenuItem value={true}>Keyword</MenuItem>
          <MenuItem value={false}>Natural Language</MenuItem>
        </Select>
        <TextField
          InputProps={{
            disableUnderline: true,
            classes: { root: props.classes.input }
          }}
          className={props.classes.input}
          placeholder={
            props.searchType
              ? "Search by keyword relevant to your topic."
              : "Search by subject or related terms."
          }
          onKeyUp={props.handleSearchInput}
          onChange={props.handleSearchInput}
          //onBlur={props.clearAutoComplete}
          value={props.search}
          autoFocus
        />
        {props.search && (
          <span className={props.classes.clear} onClick={props.clearSearch}>
            X
          </span>
        )}
        <IconButton
          className={props.classes.iconButton}
          aria-label="Search"
          onClick={props.handleSearchbutton}
        >
          <SearchIcon />
        </IconButton>
      </div>
      {props.auto_complete && props.search && (
        <div className={props.classes.width + " " + props.classes.autoComplete}>
          {props.auto_complete.map((item, index) => {
            return (
              <Paper className="autocompleteList" key={index}>
                <div
                  className={props.classes.suggestionList}
                  onClick={() => props.updateSearchQuery(item)}
                >
                  {item}
                </div>
              </Paper>
            );
          })}
        </div>
      )}
    </Paper>
  </div>
);
export default withStyles(styles)(SearchComponent);
