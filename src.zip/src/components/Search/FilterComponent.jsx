import React from "react";
import { withStyles, Paper, Button } from "@material-ui/core";
import SourceFilter from "./SourceFilter";
import DateFilter from "./DateFilter";
import ContentTypeFilter from "./ContentTypeFilter";
import { FilterHeading } from "./FilterSearchComponent";
import moment from "moment";
import {
  onSourceType,
  onFileType,
  getFileType,
  getSourceType,
  setFilter,
  resetFilters,
  getCurrentFilters
} from "./Helper";
const style = theme => ({
  section: {
    background: " #e6f2f1",
    color: "#333",
    minHeight: "120vh",
    zIndex: 100,
    padding: "0 0 1em 1em"
  },
  buttonContainer: {
    marginTop: "1em",
    textAlign: "center"
  },
  filter: {
    display: "flex",
    justifyContent: "space-between"
  },
  filterChild: {
    fontSize: "1.25rem",
    fontWeight: "bold",
    paddingRight: "1.6em",
    paddingBottom: "1.25rem"
  },
  cursor: {
    cursor: "pointer"
  },
  hrd: {
    paddingTop: "10px",
    borderTop: "1px solid #fff"
  },
  ul: {
    listStyle: "none",
    margin: 0
  },
  reset: {
    padding: 0
  },
  reset4: {
    padding: "0 0 0 15px"
  },
  perfectScroll: {
    position: "relative",
    display: "block",
    width: "100%",
    height: "100%",
    maxWidth: "100%",
    maxHeight: "100%"
  },
  button: {
    width: "80%",
    cursor: "pointer",
    fontWeight: 700
  },
  button1: {
    color: "#fff",
    backgroundColor: "#b42573",
    "&:hover": { backgroundColor: "#b42573" }
  },
  button2: { color: "#b42573", border: "solid 2px #b42573" },
  divider: {
    margin: "1em"
  }
});
class Filter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      defaultObject: props.defaultSearch,
      filterDisplayFlag: {
        dateFlag: false,
        sourceFlag: false,
        contentFlag: false
      },
      config: {
        is_on_file_type_all: false,
        is_on_file_type_pdf: false,
        is_on_file_type_image: false,
        is_on_file_type_chart: false,
        is_on_file_type_html: false,
        is_on_file_type_video: false,
        is_on_file_type_word: false,
        is_on_file_type_presentation: false,
        is_on_file_type_indd: false,
        is_on_source_all: false,
        is_on_source_internal: false,
        is_on_source_external: false,
        is_on_source_edam: false,
        is_on_source_web: false,
        is_on_source_americanfunds_advisor: false,
        is_on_source_americanfunds_ria: false,
        is_on_source_americanfunds_literature: false,
        is_on_source_thecapitalideas: false,
        is_on_source_fundfire: false,
        is_on_source_ignites: false,
        is_on_source_americanfunds_individual: false,
        is_on_source_americanfunds_retirement: false,
        is_on_source_capitalgroup_us: false,
        is_on_source_galileo: false
      },
      currentFilters: {
        source: "",
        type: "",
        timeFrame: ""
      }
    };
    this.dateSelection = this.dateSelection.bind(this);
    this.applyFilter = this.applyFilter.bind(this);
    this.updateSourcesFilter = this.updateSourcesFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
  }
  applyFilter() {
    let file_type = getFileType(this.state.config);
    const filter = this.state.defaultObject;
    filter["file_type"] = file_type;
    let source = getSourceType(this.state.config);
    filter["source"] = source;
    this.setState({
      filterDisplayFlag: {
        dateFlag: false,
        sourceFlag: false,
        contentFlag: false
      }
    });
    this.props.updateSearchQuery(filter);
  }
  showLess = status => {
    const { filterDisplayFlag } = this.state;
    filterDisplayFlag[status] = false;
    this.setState({ filterDisplayFlag });
  };
  showMore = status => {
    const { filterDisplayFlag } = this.state;
    filterDisplayFlag[status] = true;
    this.setState({ filterDisplayFlag });
  };
  dateSelection(event) {
    const { defaultObject } = this.state;
    defaultObject[event.target.name] = event.target.value;
    this.setState({ defaultObject });
  }
  resetFilter() {
    const filter = this.state.defaultObject;
    filter["source"] = [];
    filter["file_type"] = [];
    filter["time_filter_value"] = 36;
    filter["timeType"] = "Y";
    let config = resetFilters(this.state.config);
    this.setState({
      defaultObject: filter,
      filterDisplayFlag: {
        dateFlag: false,
        sourceFlag: false,
        contentFlag: false
      },
      config
    });
    this.props.updateSearchQuery(filter);
  }
  updateSourcesFilter(event, type) {
    let config;
    switch (type) {
      case "source":
        config = onSourceType(event.target.value, this.state.config);
        this.setState({ config });
        break;
      case "content":
        config = onFileType(event.target.value, this.state.config);
        this.setState({ config });
        break;
      default:
        break;
    }
  }
  componentWillMount() {
    let { defaultObject, currentFilters, config } = this.state;
    defaultObject["file_type"] = this.props.searchResult["file_type"];
    defaultObject["source"] = this.props.searchResult["source"];
    currentFilters = getCurrentFilters(
      currentFilters,
      this.props.searchResult["file_type"],
      this.props.searchResult["source"],
      this.props.searchResult["publication_from_date"],
      this.props.searchResult["publication_to_date"],
      defaultObject["time_filter_value"]
    );
    defaultObject["time_filter_value"] = this.getTimePassed(
      this.props.searchResult["publication_from_date"]
    );
    config = setFilter(config, defaultObject);
    this.setState({ defaultObject, currentFilters, config });
  }
  componentWillReceiveProps(nextProps) {
    let { defaultObject, currentFilters, config } = this.state;
    defaultObject["file_type"] = nextProps.searchResult["file_type"];
    defaultObject["source"] = nextProps.searchResult["source"];
    currentFilters = getCurrentFilters(
      currentFilters,
      nextProps.searchResult["file_type"],
      nextProps.searchResult["source"],
      nextProps.searchResult["publication_from_date"],
      nextProps.searchResult["publication_to_date"],
      defaultObject["time_filter_value"]
    );
    defaultObject["time_filter_value"] = this.getTimePassed(
      nextProps.searchResult["publication_from_date"]
    );
    config = setFilter(config, defaultObject);
    this.setState({ defaultObject, currentFilters, config });
  }
  getTimePassed(dateFrom) {
    const diffMonths = Math.floor(
      moment(new Date()).diff(moment(dateFrom), "months", true)
    );
    if (diffMonths > 24) {
      return 36;
    } else if (diffMonths > 12 && diffMonths <= 24) {
      return 24;
    } else if (diffMonths > 3 && diffMonths <= 12) {
      return 12;
    } else if (diffMonths === 3) {
      return 3;
    } else if (diffMonths === 2) {
      return 2;
    } else if (diffMonths === 1) {
      return 1;
    } else {
      return 36;
    }
  }
  render() {
    const {
      defaultObject,
      currentFilters,
      filterDisplayFlag,
      config
    } = this.state;
    const { classes } = this.props;
    const headingClasses = {
      filter: classes.filter,
      filterChild: classes.filterChild
    };
    return (
      <Paper>
        <section className={classes.section}>
          <FilterHeading classes={headingClasses} action={this.props.action} />
          <div>
            <div className={classes.perfectScroll}>
              <div>
                <DateFilter
                  defaultObject={defaultObject}
                  dateSelection={this.dateSelection}
                  filterDisplayFlag={filterDisplayFlag}
                  showMore={this.showMore}
                  showLess={this.showLess}
                  currentFilters={currentFilters}
                />
                <SourceFilter
                  config={config}
                  updateSourcesFilter={this.updateSourcesFilter}
                  filterDisplayFlag={filterDisplayFlag}
                  showMore={this.showMore}
                  showLess={this.showLess}
                  currentFilters={currentFilters}
                />
              </div>
              <ContentTypeFilter
                updateContentFilter={this.updateSourcesFilter}
                config={config}
                filterDisplayFlag={filterDisplayFlag}
                showMore={this.showMore}
                showLess={this.showLess}
                currentFilters={currentFilters}
              />
            </div>
          </div>

          <div className={classes.buttonContainer}>
            <Button
              //variant="outlined"
              className={classes.button + " " + classes.button1}
              onClick={this.applyFilter}
            >
              Apply Filters
            </Button>
            <div className={classes.divider} />
            <Button
              variant="outlined"
              className={classes.button + " " + classes.button2}
              onClick={this.resetFilter}
            >
              Reset Filters
            </Button>
          </div>
        </section>
      </Paper>
    );
  }
}
export default withStyles(style)(Filter);