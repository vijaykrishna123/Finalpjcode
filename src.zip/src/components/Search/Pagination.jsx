import React from "react";
import Fab from "@material-ui/core/Fab";
import { withStyles } from "@material-ui/core";
const styles = theme => ({
  root: {
    display: "flex",
    justifyContent: "center",
    padding: "1em"
  },
  button: {
    margin: theme.spacing.unit / 2,
    color: "#005f9e",
    border: "solid 2px #005f9e"
  },
  active: {
    backgroundColor: "#005f9e",
    color: "#fff !important"
  }
});
const Pagination = ({ classes, search, changePage }) => {
  const remainingPage = search.record_count % search.page_size;

  let totalPage = Math.floor(search.record_count / search.page_size);
  if (remainingPage) totalPage += 1;
  const list = new Array(totalPage).fill(1);
  return (
    <div className={classes.root}>
      {list.map((item, index) => {
        const color =
          search.offset === index + 1
            ? `${classes.active} ${classes.button}`
            : classes.button;

        return (
          <Fab
            key={index}
            aria-label="Add"
            className={color}
            onClick={() => changePage(index + 1)}
          >
            {index + 1}
          </Fab>
        );
      })}
    </div>
  );
};
export default withStyles(styles)(Pagination);
