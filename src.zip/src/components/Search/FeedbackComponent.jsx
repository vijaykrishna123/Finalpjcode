import React from "react";
import { withStyles } from "@material-ui/core";
import SentimentVerySatisfied from "@material-ui/icons/SentimentVerySatisfied";
import SentimentSatisfied from "@material-ui/icons/SentimentSatisfied";
import SentimentVeryDissatisfied from "@material-ui/icons/SentimentVeryDissatisfied";
import MoodBad from "@material-ui/icons/MoodBad";

const style = theme => ({
  smallemoji: {
    display: "inline-block",
    cursor: "pointer",
    color: "#707070",
    marginLeft: "25px"
  },
  bigemoji: {
    display: "inline-block",
    cursor: "pointer",
    color: "#707070",
    marginLeft: "25px"
  },
  activeEmoji: {
    color: "#005f9e"
  },
  rate: {
    color: "#005f9e",
    fontSize: "16px",
    fontWeight: 800
  }
});

const Feedback = props => {
  const { classes, feedbackKey } = props;
  return (
    <div className={"feedback-list"}>
      <span className={classes.rate}>RATE</span>
      {props.data.map((feedback, index) => {
        let partial;
        if (feedback.very_good) {
          partial = (
            <div
              key={index}
              onClick={() => props.sendFeedback("vlike")}
              className={
                feedbackKey === "vlike"
                  ? `${classes.smallemoji} ${classes.activeEmoji}`
                  : classes.smallemoji
              }
            >
              <SentimentVerySatisfied />
              <span>Great</span>
            </div>
          );
        } else if (feedback.good) {
          partial = (
            <div
              key={index}
              onClick={() => props.sendFeedback("like")}
              className={
                feedbackKey === "like"
                  ? `${classes.smallemoji} ${classes.activeEmoji}`
                  : classes.smallemoji
              }
            >
              <SentimentSatisfied />
              <span>Good</span>
            </div>
          );
        } else if (feedback.neutral === 0) {
          partial = (
            <div
              key={index}
              onClick={() => props.sendFeedback("neutral")}
              className={
                feedbackKey === "neutral"
                  ? `${classes.bigemoji} ${classes.activeEmoji}`
                  : classes.bigemoji
              }
            >
              <SentimentVeryDissatisfied />
              <span>Not Sure</span>
            </div>
          );
        } else {
          partial = (
            <div
              key={index}
              onClick={() => props.sendFeedback("dislike")}
              className={
                feedbackKey === "dislike"
                  ? `${classes.bigemoji} ${classes.activeEmoji}`
                  : classes.bigemoji
              }
            >
              <MoodBad />
              <span>Not Helpful</span>
            </div>
          );
        }

        return partial;
      })}
    </div>
  );
};

export default withStyles(style)(Feedback);
