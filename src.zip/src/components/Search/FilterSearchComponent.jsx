import React from "react";
import { Typography } from "@material-ui/core";
import Add from "@material-ui/icons/Add";
import Remove from "@material-ui/icons/Remove";

export const FilterHeading = ({ classes, action }) => {
  return (
    <div className={"pt-4 pb-8 " + classes.filter}>
      <Typography component="span" className={classes.filterChild}>
        Filters
      </Typography>
    </div>
  );
};

export const ViewLess = ({ action }) => {
  return (
    <div onClick={action} style={{ float: "right", cursor: "pointer", width: "30px", display : "inline-block" }}>
      <Remove />
    </div>
  );
};
export const ViewMore = ({ action }) => {
  return (
    <div onClick={action} style={{ float: "right", cursor: "pointer", width: "30px", display : "inline-block" }}>
      <Add />
    </div>
  );
};
