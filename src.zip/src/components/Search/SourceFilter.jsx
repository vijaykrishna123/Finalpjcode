import React, { Fragment } from "react";
import { withStyles, Checkbox } from "@material-ui/core";
import { ViewLess, ViewMore } from "./FilterSearchComponent";
const styles = theme => ({
  root: {
    "&$checked": {
      color: "#0089c9"
    }
  },
  checked: {},
  hrd: {
    paddingTop: "10px",
    paddingBottom: "10px",
    borderTop: "1px solid #fff"
  },
  ul: {
    listStyle: "none",
    margin: 0
  },
  reset: {
    padding: 0
  },
  reset4: {
    padding: "0 0 0 15px"
  }
});
const sourceConfig = [
  {
    name: "is_on_source_all",
    value: "all",
    title: "All Sources",
    flag: ""
  },
  {
    name: "is_on_source_internal",
    value: "internal",
    title: "Internal Only",
    flag: "",
    child: [
      {
        name: "is_on_source_edam",
        value: "edam",
        title: "eDAM",
        flag: ""
      },
      {
        name: "is_on_source_galileo",
        value: "galileo",
        title: "Galileo",
        flag: ""
      },
      {
        name: "is_on_source_web",
        value: "web",
        title: "Web",
        flag: "",
        child: [
          {
            name: "is_on_source_thecapitalideas",
            value: "thecapitalideas",
            title: "The Capital Ideas",
            flag: true
          },
          {
            name: "is_on_source_americanfunds_advisor",
            value: "americanfunds_advisor",
            title: "AF Advisor",
            flag: true
          },
          {
            name: "is_on_source_americanfunds_ria",
            value: "americanfunds_ria",
            title: "AF RIA",
            flag: true
          },
          {
            name: "is_on_source_americanfunds_literature",
            value: "americanfunds_literature",
            title: "AF Literature",
            flag: true
          },
          {
            name: "is_on_source_americanfunds_individual",
            value: "americanfunds_individual",
            title: "AF Investor",
            flag: true
          },
          {
            name: "is_on_source_americanfunds_retirement",
            value: "americanfunds_retirement",
            title: "AF Retirement",
            flag: true
          },
          {
            name: "is_on_source_capitalgroup_us",
            value: "capitalgroup_us",
            title: "AF Institutional",
            flag: true
          }
        ]
      }
    ]
  },
  {
    name: "is_on_source_external",
    value: "external",
    title: "All External",
    flag: true,
    child: [
      {
        name: "is_on_source_fundfire",
        value: "fundfire",
        title: "Fundfire",
        flag: true
      },
      {
        name: "is_on_source_ignites",
        value: "ignites",
        title: "Ignites",
        flag: true
      }
    ]
  }
];
const SourceFilter = ({
  classes,
  config,
  updateSourcesFilter,
  filterDisplayFlag,
  showMore,
  showLess,
  currentFilters
}) => {
  const subList = sourcewebs => {
    return (
      <ul className={classes.ul + " " + classes.reset4}>
        {sourcewebs.map(item => {
          return (
            <Fragment>
                <li key={item.name}>
                  <Checkbox
                    checked={config[item.name]}
                    onChange={event => updateSourcesFilter(event, "source")}
                    value={item.value}
                    classes={{
                      root: classes.root,
                      checked: classes.checked
                    }}
                  />
                  <label>{item.title}</label>
                  {item.child && subList(item.child)}
                </li>
            </Fragment>
          );
        })}
      </ul>
    );
  };
  return (
    <Fragment>
      <div className={"filter-section"}>
      <div className={classes.hrd}>
        <span className="title filter-title">Source</span>
        {filterDisplayFlag["sourceFlag"] ? (
            <ViewLess action={() => showLess("sourceFlag")} />
        ) : (
            <ViewMore action={() => showMore("sourceFlag")} />
        )}
      </div>
      {filterDisplayFlag["sourceFlag"] ? (
        <ul className={classes.ul + " " + classes.reset}>
          {sourceConfig.map(source => {
            return (
              <Fragment>
                  <li key={source.name}>
                    <Checkbox
                      checked={config[source.name]}
                      onChange={event => updateSourcesFilter(event, "source")}
                      value={source.value}
                      classes={{
                        root: classes.root,
                        checked: classes.checked
                      }}
                    />
                    <label>{source.title}</label>
                    {source.child && subList(source.child)}
                  </li>
              </Fragment>
            );
          })}
        </ul>
        ) : (
          <div className={"filter-current-selections"}>
            {currentFilters["source"]}
          </div>
        )}
        </div>
    </Fragment>
  );
};
export default withStyles(styles)(SourceFilter);
