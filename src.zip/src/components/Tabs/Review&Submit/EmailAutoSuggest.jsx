import React, { Fragment } from "react";
import { withStyles } from "@material-ui/core/styles";
import compose from "recompose/compose";
import { connect } from "react-redux";
import Autosuggest from "react-autosuggest";
import ChipButton from "../../Common/ChipButton";
import { Button, TextField } from "@material-ui/core";
import LockIcon from "@material-ui/icons/Lock";
import {
  createProofRequest,
  addReviewer,
  shareReviewer,
  shareProof,
  shareProofVersion,
  fetchReviewer,
  removeCollaborator,
  addCollaboratorToWriteSuccess,
  showSuccessMsg,
  sendPdfToWorkfront
} from "../../../redux/actions/writeAction";
import { fetchInitialUsers } from "../../../redux/actions/userActions";

const styles = theme => ({
  title: {
    fontWeight: "bold",
    padding: "10px",
    backgroundColor: "#cccccc",
    margin: 0
  },
  reviewtitle: {
    fontWeight: "bold"
  },
  body: {
    padding: "10px",
    border: "solid 1px #cccccc"
  },
  container: {
    display: "flex",
    flexWrap: "wrap"
  },
  margin: {
    margin: theme.spacing.unit
  },
  cssFocused: {},
  bootstrapRoot: {
    padding: 0,
    "label + &": {
      marginTop: theme.spacing.unit * 3
    }
  },
  errorIcon: {
    color: "#b42573",
    fontWeight: "bold",
    fontSize: "18px"
  },
  error: {
    color: "#b42573",
    marginLeft: "5px",
    fontWeight: "bold"
  },
  comments: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important"
  },
  paper: {
    position: "absolute",
    width: theme.spacing.unit * 50,
    backgroundColor: theme.palette.background.paper,
    boxShadow: theme.shadows[5],
    padding: theme.spacing.unit * 4
  },
  bootstrapInput: {
    borderRadius: 4,
    backgroundColor: theme.palette.common.white,
    border: "1px solid #ced4da",
    fontSize: 16,
    padding: "10px 12px",
    width: "80%",
    margin: "0px 0px",
    transition: theme.transitions.create(["border-color", "box-shadow"]),
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"'
    ].join(","),
    "&:focus": {
      borderColor: "#80bdff",
      boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)"
    }
  },
  bootstrapFormLabel: {
    fontSize: 18
  },
  btnWrapper: {
    margin: "15px 0px"
  },
  genProofBtn: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important",
    width: "100%"
  },
  addColBtn: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important",
    width: "100%",
    border: "2px solid #005f9e !important",
    "&:hover": {
      border: "2px solid #005f9e",
      backgroundColor: "rgba(0,95,158,0.2)"
    }
  },
  goToProofBtn: {
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important",
    width: "100%",
    backgroundColor: "transparent !important",
    marginBottom: "0px !important",
    textDecoration: "underline"
  },
  disabled: {
    color: "#99999 !important"
  },
  enabled: {
    color: "#005f9e !important"
  },
  lockIcon: {
    marginLeft: "5px",
    marginTop: "-5px",
    fontSize: "12px"
  }
});

const escapeRegexCharacters = str => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

class EmailAutoSuggest extends React.Component {
  constructor(props) {
    super(props);
    const writeAssignment = props.writes?.write?.assignment;
    let emailText = "";
    if (writeAssignment?.stateId === 2) {
      emailText = "Hey all, check out the latest proof for creative review.";
    }
    if (writeAssignment?.stateId === 3) {
      emailText =
        "Hey all, we finalized the creative circ, the legal circ is ready for review.";
    }
    this.state = {
      name: "",
      emailText: emailText,
      tagArr: [],
      value: "",
      audienceRef: "",
      tagFilterArr: [],
      storeArray: [],
      open: false,
      suggestions: [],
      alertOpen: false,
      imageIcon: "",
      message: "",
      isLinkPresent: false,
      error: ""
    };
  }

  remove = (value, index) => {
    this.props.removeCollaborator({ index });
    this.props.showMessage(
      `${value.userInitials} removed successfully`,
      "success"
    );
  };

  getSuggestions = (value = "") => {
    this.setState({ error: "" });
    const inputValue = value.trim().toLowerCase();
    const inputLength = inputValue.length;
    const escapedValue = escapeRegexCharacters(value.trim());
    if (inputLength === 0 || escapedValue === "") {
      return [];
    }
    const output = this.props.initialUsers.filter(
      suggestion =>
        suggestion.userInitials.toLowerCase().slice(0, inputLength) ===
        inputValue
    );
    if (!output.length) {
      this.setState({ error: "Please enter valid Initials." });
    }
    return output;
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: this.getSuggestions(value)
    });
  };
  onSuggestionsClearRequested = () => {};
  getSuggestionValue = suggestion => {
    return suggestion.emailId;
  };
  renderSuggestion = suggestion => {
    return suggestion.userInitials;
  };
  onSuggestionSelected = (event, { suggestion }) => {
    const {
      addCollaboratorToWriteSuccess,
      writes,
      latestProof,
      proofURL,
      assignment,
      user
    } = this.props;
    if (!proofURL) {
      addCollaboratorToWriteSuccess(suggestion);
      const obj = {
        commentValue: "@" + suggestion.userInitials?.trim(),
        commentStatus: "",
        percolateId: assignment.id,
        replyToId: 0,
        userInitials: user.userId,
        optionalText: "",
        assignmentName: assignment.name
      };
      this.props.shareReviewer(obj);
    } else {
      const fileId = latestProof
        ? latestProof.fileId
        : writes.write?.assignment?.proofFileId;

      if (!suggestion.userInitials || !fileId) return;
      this.props.addReviewer({
        initial: suggestion.userInitials,
        emailId: suggestion.emailId,
        fileId,
        assignment,
        user
      });
    }
    this.props.showMessage(
      `${suggestion.userInitials} added successfully`,
      "success"
    );
    this.setState({ value: "" });
  };
  onChangeInput = (event, option) => {
    this.setState({ value: option.newValue });
  };

  sendProof = () => {
    const { emailText } = this.state;
    const {
      createProofRequest,
      assignment,
      writes,
      user,
      collaborators,
      showMessage,
      proofURL
    } = this.props;
    createProofRequest({
      assignmentId: assignment.id,
      assignmentName: assignment.name,
      recipients: collaborators,
      fileID: writes.write?.assignment?.proofFileId,
      emailID: user.emailId,
      emailText,
      user,
      proofURL,
      showMessage
    });

    this.setState({ emailText: "" });
  };

  sendPdfToWorkfront = () => {
    const { emailText } = this.state;
    let assignment = this.props.writes?.write?.assignment;
    if (!assignment?.workfrontJobId) {
      this.props.showMessage(
        `Please enter the Workfront Job # in percolate`,
        "error"
      );
      return;
    }
    let workfrontDocId = "",
      workfrontSocialDocId = "",
      workfrontLinkedDocId = "";
    if (this.props.writes?.write?.workfront) {
      this.props.writes.write.workfront.forEach(wf => {
        if (!workfrontDocId && wf.workfrontDocId && wf.pdfCategory === "FULL") {
          workfrontDocId = wf.workfrontDocId;
        }
        if (
          !workfrontSocialDocId &&
          wf.workfrontDocId &&
          wf.pdfCategory === "LEGAL_SOCIAL_POSTS"
        ) {
          workfrontSocialDocId = wf.workfrontDocId;
        }
        if (
          !workfrontLinkedDocId &&
          wf.workfrontDocId &&
          wf.pdfCategory === "LEGAL_LINKEDIN_ELEVATE"
        ) {
          workfrontLinkedDocId = wf.workfrontDocId;
        }
      });
    }
    if (!workfrontDocId) {
      workfrontDocId = assignment.workfrontDocId;
    }
    if (!workfrontSocialDocId) {
      workfrontSocialDocId = assignment.workfrontSocialDocId;
    }
    if (!workfrontLinkedDocId) {
      workfrontLinkedDocId = assignment.workfrontLinkedDocId;
    }
    const payload = {
      id: assignment.percolateId,
      assignmentName: assignment.assignmentName,
      referenceNumber: assignment.workfrontJobId,
      newVersion: !!workfrontDocId,
      workfrontDocId,
      workfrontSocialDocId,
      workfrontLinkedDocId,
      pdfCategory: "FULL",
      workfrontDocName: assignment.workfrontDocName,
      showMessage: this.props.showMessage,
      recipients: this.props.collaborators,
      user: this.props.user,
      emailText
    };
    this.props.sendPdfToWorkfront(payload);
    this.setState({ emailText: "" });
  };

  commentHandler = e => {
    const emailText = e.target.value;
    this.setState({ emailText });
  };

  componentDidMount() {
    const {
      latestProof,
      writes,
      fetchInitialUsers,
      fetchReviewer,
      user
    } = this.props;
    fetchInitialUsers();
    const fileId = latestProof
      ? latestProof.fileId
      : writes.write?.assignment?.proofFileId;

    if (fileId && !writes.write?.assignment?.reviewerLoaded) {
      fetchReviewer({ fileId, emailId: user.emailId });
    }
  }
  render() {
    const { value, suggestions, emailText, error } = this.state;
    const { collaborators, classes, proofURL, assignment } = this.props;
    const inputSuggestionProps = {
      placeholder: "add",
      value,
      onChange: this.onChangeInput,
      id: "bootstrap-input"
    };
    const writes = this.props.writes;
    const writeAssignment = writes?.write?.assignment || {};
    const reviewStarted = !!writes?.write?.assignment?.workfrontDocId;

    return (
      <div className="email-container">
        {writeAssignment.stateId === 2 || writeAssignment.stateId === 3 ? (
          <h5 className={classes.title}> {writeAssignment.stateName}</h5>
        ) : null}
        <div className={classes.body}>
          <h5 className={classes.reviewtitle}> Notification </h5>
          <div className={`input-group ${error ? "error" : ""}`}>
            <ChipButton
              chipButtonValues={collaborators}
              onClose={this.remove}
            />
            <Autosuggest
              suggestions={suggestions}
              onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
              onSuggestionsClearRequested={this.onSuggestionsClearRequested}
              getSuggestionValue={this.getSuggestionValue}
              renderSuggestion={this.renderSuggestion}
              onSuggestionSelected={this.onSuggestionSelected}
              inputProps={inputSuggestionProps}
            />
            {error ? <span className={classes.errorIcon}>!</span> : null}
          </div>
          {error ? <div className={classes.error}>{error}</div> : null}
          <div>
            <TextField
              id="outlined-bare"
              value={emailText}
              fullWidth={true}
              className={classes.comments}
              margin="normal"
              multiline
              rows="4"
              variant="outlined"
              inputProps={{ "aria-label": "bare" }}
              onChange={this.commentHandler}
              placeholder={"Comments(optional)"}
            />
          </div>

          {writeAssignment.stateId === 2 ? (
            <Fragment>
              <div className={classes.btnWrapper}>
                <Button
                  variant="contained"
                  className={`${classes.addColBtn}  btn-solid-blue`}
                  disabled={!collaborators.length || reviewStarted}
                  onClick={this.sendProof}
                >
                  GENERATE CREATIVE PROOF
                </Button>
              </div>
              <div className={classes.btnWrapper}>
                <Button
                  href={proofURL}
                  className={`${classes.goToProofBtn} ${
                    !proofURL ? classes.disabled : classes.enabled
                  }`}
                  target="_blank"
                  color="primary"
                  disabled={!proofURL}
                >
                  GO TO CREATIVE PROOF{" "}
                  {reviewStarted ? (
                    <span className={classes.lockIcon}>
                      <LockIcon />
                    </span>
                  ) : null}
                </Button>
              </div>
            </Fragment>
          ) : null}

          {!assignment.isDraft && writeAssignment.stateId === 3 ? (
            <Fragment>
              <div className={classes.btnWrapper}>
                <Button
                  onClick={this.sendPdfToWorkfront}
                  className={`${classes.addColBtn} btn-solid-blue`}
                  target="_blank"
                  color="primary"
                >
                  Send Legal proof to Workfront
                </Button>
              </div>
              <div className={classes.btnWrapper}>
                <Button
                  href={writeAssignment.workfrontURL}
                  className={`${classes.goToProofBtn} ${
                    !writeAssignment.workfrontURL
                      ? classes.disabled
                      : classes.enabled
                  }`}
                  target="_blank"
                  color="primary"
                  disabled={!writeAssignment.workfrontURL}
                >
                  GO TO WORKFRONT TASK
                </Button>
              </div>
            </Fragment>
          ) : null}
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  const personalProof = state.write.personalUrl;
  const proofLists = Object.assign([], state.write.proofUrl);
  const latestProof = proofLists.length > 0 ? proofLists.reverse().shift() : {};
  const proofURL = personalProof ? personalProof : latestProof.proofUrl;

  return {
    latestProof,
    proofURL,
    writes: state.write,
    user: state.user,
    initialUsers: state.user.initialUsers,
    assignment: state.assignments.assignment
  };
};

export default compose(
  withStyles(styles),
  connect(mapStateToProps, {
    createProofRequest,
    addCollaboratorToWriteSuccess,
    removeCollaborator,
    fetchInitialUsers,
    addReviewer,
    shareReviewer,
    shareProof,
    shareProofVersion,
    fetchReviewer,
    showSuccessMsg,
    sendPdfToWorkfront
  })
)(EmailAutoSuggest);
