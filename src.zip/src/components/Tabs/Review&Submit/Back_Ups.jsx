import React from "react";
import { GridListTile, Typography } from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import configDeterminator from "../../../configs/configDeterminator";

const BackUps = props => {
  if (!props.data || props.data.length < 2) return null;
  const title = props.title || "Backup";
  const subUrl = props.subUrl || "backups";
  const urlKey = props.urlKey || "backupId";
  return (
    <div className="review-backup-block review-subsection">
      <Grid container direction="row" justify="center" alignItems="center">
        <Grid item xs={12}>
          <Typography component="h3">
            <strong>{title}</strong>
          </Typography>
          {props.data
            .filter(
              backup =>
                backup.name !== "" &&
                backup.name !== "<p></p>" &&
                backup.name !== "N/A"
            )
            .map((backup, index) => (
              <GridListTile
                key={index}
                component="a"
                target="_blank"
                href={`${configDeterminator.cwbApiEndpoint}/${subUrl}/${backup[urlKey]}`}
                className={"review-backup-link"}
              >
                <Typography>{backup.name}</Typography>
              </GridListTile>
            ))}
        </Grid>
      </Grid>
    </div>
  );
};

export default BackUps;
