import React, { useEffect } from "react";
import { withStyles } from "@material-ui/core/styles";
import * as R from "ramda";
import { connect } from "react-redux";
import {
  createProofRequest,
  updateProofAction,
  addCollaborator,
  removeCollaborator,
  fetchPersonalUrl
} from "../../../redux/actions/writeAction";
import { shareUrlToOther } from "../../../redux/actions/commentAction";
import EmailAutoSuggest from "./EmailAutoSuggest";

const styles = theme => {
  return {
    root: {},
    heading: {
      fontWeight: 300,
      color: "#255d63",
      fontSize: "28px"
    },
    reviewContent: {
      color: "#000000",
      fontSize: "16px",
      fontWeight: "normal",
      fontfamily: "Avenir-Roman"
    },

    proofContainer: {
      display: "flex",
      flexDirection: "column",
      padding: "1rem",
      flex: 1,
      marginBottom: "15px"
    },
    textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit
    }
  };
};

const ReviewSubmit = props => {
  const {
    writes,
    fetchPersonalUrl,
    user,
    showMessage,
    shareUrlToOther
  } = props;
  const collaborators =
    writes.write && writes.write.assignment.collaborators
      ? writes.write.assignment.collaborators
      : [];

  useEffect(() => {
    const payload = {
      fileID: writes.write.assignment.proofFileId,
      emailID: `${user.emailId}`
    };
    fetchPersonalUrl(payload);
  }, []);

  if (writes && R.isEmpty(writes.write)) props.history.push("/");

  return (
    <EmailAutoSuggest
      collaborators={collaborators}
      showMessage={showMessage}
      shareUrlToOther={shareUrlToOther}
    />
  );
};

const mapStateToProps = ({ write, disclosures, assignments, user }) => {
  return {
    writes: write,
    disclosure: disclosures.disclosure,
    assignment: assignments.assignment,
    user: user
  };
};

export default withStyles(styles)(
  connect(
    mapStateToProps,
    {
      createProofRequest,
      updateProofAction,
      addCollaborator,
      removeCollaborator,
      fetchPersonalUrl,
      shareUrlToOther
    }
  )(ReviewSubmit)
);
