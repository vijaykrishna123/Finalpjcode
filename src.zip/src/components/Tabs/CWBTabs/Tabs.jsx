import React, { Fragment } from "react";
import { withRouter } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import classNames from "classnames";
import Tab from "./Tab";
import Drawer from "@material-ui/core/Drawer";
import Button from "@material-ui/core/Button";
import List from "@material-ui/core/List";
import CloseIcon from "@material-ui/icons/Close";
import MenuIcon from "@material-ui/icons/Menu";
import FeedbackDialog from "../../Popups/Feedback";

const drawerWidth = 250;
const styles = theme => {
  return {
    root: {
      flexGrow: 1,
      zIndex: 1,
      overflow: "hidden",
      position: "relative",
      display: "flex"
    },
    logoWrapper: {
      height: "64px",
      color: "#fff",
      display: "flex",
      alignItems: "center",
      fontSize: "24px",
      margin: "0px 10px",
      padding: "10px"
    },
    drawerPaper: {
      position: "inherit",
      whiteSpace: "nowrap",
      width: drawerWidth,
      transition: theme.transitions.create("width", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen
      }),
      backgroundColor: "#00294b",
      overflow: "auto",
      height: "100%"
    },
    collapseDrawer: {
      width: "100px !important"
    },
    drawerPaperClose: {
      overflowX: "hidden",
      transition: theme.transitions.create("width", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen
      }),
      width: "250px !important",
      [theme.breakpoints.up("sm")]: {
        width: theme.spacing.unit * 9
      }
    },
    toolbar: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      padding: "0 8px",
      ...theme.mixins.toolbar
    },
    toolbarTitle: {
      flex: 1,
      position: "relative"
    },
    separator: {
      border: "solid 1px #005f9e",
      margin: "10px 0px"
    },
    btnWrapper: {
      margin: "15px 20px"
    },
    feedbackbtn: {
      color: "#fff",
      border: "1px solid #fff",
      width: "100%"
    },
    title: {
      fontSize: "16px",
      fontWeight: "normal"
    },
    closeIcon: {
      fontSize: "24px",
      marginLeft: "10px",
      marginRight: "15px",
      marginTop: "-5px"
    },
    menuIcon: {
      marginLeft: "15px",
      marginTop: "-20px",
      fontSize: "30px"
    },
    logo: {
      width: "54px",
      height: "30px",
      objectFit: "contain",
      marginTop: "0px"
    }
  };
};

const WriteTabs = [
  { name: "Projects", path: "/", icon: "dashboard", tooltip: "" },
  {
    name: "Overview",
    path: "/overview",
    icon: "",
    tooltip: "",
    background: true
  },
  {
    name: "Write",
    path: "/write",
    icon: "",
    disable: false,
    background: true
  },
  {
    name: "Resources",
    path: "/resources",
    icon: "list",
    disable: false
  },
  {
    name: "Discover",
    path: "/research?standalone",
    icon: "search",
    tooltip: ""
  },
  {
    name: "Disclosure",
    path: "/disclosures",
    icon: "info",
    tooltip: ""
  }
];

const dashboardTabs = [
  { name: "Projects", path: "/", icon: "dashboard", tooltip: "" },
  {
    name: "Resources",
    path: "/resources",
    icon: "list",
    disable: false
  },
  {
    name: "Discover",
    path: "/research?standalone",
    icon: "search",
    disable: false
  },
  {
    name: "Disclosure",
    path: "/disclosures?standalone",
    icon: "info",
    disable: false
  }
];
class Tabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: "Projects",
      open: true,
      openFeedForm: false
    };
  }
  onTabClick = (activeTab, disable) => {
    if (disable) return;
    this.setState({
      activeTab
    });
  };

  getActiveTab = () => {
    let { activeTab } = this.state;
    const { location } = this.props;
    const path = location.pathname + location.search;
    if (path === "/") activeTab = "Projects";
    if (path === "/write") activeTab = "Write";
    if (path === "/resources") activeTab = "Resources";
    if (path === "/research?standalone") activeTab = "Discover";
    if (path === "/overview") activeTab = "Overview";
    if (path === "/disclosures") activeTab = "Disclosure";
    if (path === "/disclosures?standalone") activeTab = "Disclosure";
    if (path.includes("/post")) activeTab = "Write";

    return activeTab;
  };

  renderTabs = () => {
    let tabNames =
      this.props && this.props.dashBoardLoaded ? dashboardTabs : WriteTabs;
    let activeTab = this.getActiveTab();
    return tabNames.map(
      ({ name, path, icon, disable, tooltip, background = false }, index) => {
        return (
          <Tab
            key={index}
            label={name}
            to={path}
            disable={disable}
            tooltip={tooltip}
            icon={icon}
            activeTab={activeTab}
            background={background}
            collapse={this.props.collapse}
            onTabClick={() => this.onTabClick(name, disable)}
          />
        );
      }
    );
  };

  openFeedbackForm = () => {
    this.setState({ openFeedForm: true });
  };
  closeFeedbackForm = () => {
    this.setState({ openFeedForm: false });
  };
  render() {
    const { classes, collapse, toggleCollapse } = this.props;
    return (
      <Drawer
        variant="permanent"
        classes={{
          paper: classNames(
            classes.drawerPaper,
            "drawer_block",
            `${collapse ? classes.collapseDrawer : ""}`
          )
        }}
        open={this.state.open}
      >
        <div className={classes.toolbar} />

        {this.state.openFeedForm ? (
          <FeedbackDialog handleClose={this.closeFeedbackForm} />
        ) : null}

        <List
          className={`navigation ${collapse ? classes.collapseDrawer : ""}`}
        >
          <div className={classes.logoWrapper} onClick={toggleCollapse}>
            <Fragment>
              {!collapse ? (
                <div className={classes.title}>
                  <CloseIcon className={classes.closeIcon} />
                  <span>MENU</span>
                </div>
              ) : (
                <div className={classes.menuIcon}>
                  <MenuIcon />{" "}
                </div>
              )}
            </Fragment>
          </div>

          {!collapse ? (
            <Fragment>
              {this.renderTabs()}
              <div className={classes.separator}></div>
              <div className={classes.btnWrapper}>
                <Button
                  variant="outlined"
                  className={`${classes.button} ${classes.feedbackbtn}`}
                  onClick={this.openFeedbackForm}
                >
                  Share your feedback
                </Button>
              </div>
            </Fragment>
          ) : null}
        </List>
      </Drawer>
    );
  }
}

const TabsWithRouter = withRouter(Tabs);

export default withStyles(styles)(TabsWithRouter);
