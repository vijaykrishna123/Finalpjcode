import React, { Component } from "react";
import "./../../../assets/scss/options.css";
import arrowrightIcon from "../../../assets/images/Disclosure/arrow-right.svg";
import arrowdownIcon from "../../../assets/images/Disclosure/arrow-drop-down.svg";

const imagesIcons = {
  minusSign: arrowdownIcon,
  plusSign: arrowrightIcon
};
class ToggleChild extends Component {
  constructor(props) {
    super(props);
    this.state = {
      imageOpen: true
    };
  }
  toggleButtonSign = e => {
    this.setState(state => ({ imageOpen: !state.imageOpen }));
    this.props.onClick(e);
  };
  getImageIcon = () => (this.state.imageOpen ? "plusSign" : "minusSign");

  render() {
    const imageIcon = this.getImageIcon();
    return (
      <img
        className="imageToggleClass"
        src={imagesIcons[imageIcon]}
        onClick={this.toggleButtonSign}
        id={this.props.id}
        alt="icon"
      />
    );
  }
}

export default ToggleChild;
