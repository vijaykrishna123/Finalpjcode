import React from "react";
import copyicon from "../../../assets/images/Disclosure/icon-copy.svg";
import { connect } from "react-redux";
import { Button } from "reactstrap";
import FileCopy from "@material-ui/icons/FileCopyOutlined";
import Done from "@material-ui/icons/Done";
import { generatePdf } from "../../../redux/actions/disclosureActions";

class DisclosureList extends React.Component {
  copyDisclosure(varDivId, varClassName) {
    var disclosureSelect,
      disclosureLanguagePath = "",
      range,
      selection,
      text;
    disclosureSelect = document.getElementsByClassName(varClassName);
    for (var i = 0; i < disclosureSelect.length; i++) {
      disclosureLanguagePath =
        disclosureLanguagePath + disclosureSelect[i].innerHTML + "<br/><br/>";
    }
    document.getElementById(varDivId).innerHTML = disclosureLanguagePath;
    text = document.getElementById(varDivId);
    if (document.body.createTextRange) {
      range = document.body.createTextRange();
      range.moveToElementText(text);
      range.select();
    } else if (window.getSelection) {
      selection = window.getSelection();
      range = document.createRange();
      range.selectNodeContents(text);
      selection.removeAllRanges();
      selection.addRange(range);
    }
    document.execCommand("copy");
    window.getSelection().removeAllRanges();
    document.getElementById(varDivId).innerHTML = "";
    this.props.textCopied();
  }

  render() {
    let disclosureItems =
      this.props.disclosure && this.props.disclosure.Results;
    return (
      <div>
        {typeof disclosureItems !== "undefined" &&
          disclosureItems.length > 0 &&
          this.props.mode === "regular" && (
            <div className="apply-disclosure-template">
              <Button
                variant="contained"
                color="primary"
                onClick={this.props.onClick}
              >
                <FileCopy /> APPLY RESULTS TO TEMPLATE
              </Button>
            </div>
          )}
        {typeof disclosureItems !== "undefined" &&
          disclosureItems.length > 1 &&
          this.props.mode === "standalone" && (
            <div>
              <img
                alt="disclosure-icon-copy"
                className="disclosure-icon-copy"
                src={copyicon}
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-text")
                }
              />
              <span
                className="copy-all-disclosure"
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-text")
                }
              >
                COPY ALL DISCLOSURE LANGUAGE
              </span>
              &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
              <img
                alt="disclosure-icon-copy"
                className="disclosure-icon-copy"
                src={copyicon}
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-path")
                }
              />
              <span
                className="copy-all-disclosure"
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-path")
                }
              >
                COPY ALL DMC PATHS
              </span>
              &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
              <Button
                variant="contained"
                className="generate-pdf"
                color="primary"
                onClick={() =>
                  this.props.generatePdf(this.props.filters.tagFilter)
                }
              >
                <Done /> Generate PDF
              </Button>
            </div>
          )}

        <div className="disclosure-line" />
        <div className="disclosure-list-item">
          {disclosureItems &&
            disclosureItems.map((disclosure, index) => (
              <div key={index}>
                <div
                  className="disclosure-text"
                  dangerouslySetInnerHTML={{ __html: disclosure.language }}
                />
                <div className="disclosure-path">
                  <div
                    dangerouslySetInnerHTML={{
                      __html: disclosure.renditionPath
                        .toString()
                        .replace(/,/g, "<br/>\n")
                    }}
                  />
                </div>
                <hr />
              </div>
            ))}
          {typeof disclosureItems === "undefined" && (
            <div className="disclosure-empty-text">
              To use the Disclosure tool, choose filters for your content in the
              categories given.
              <br />
              Select "apply" to view the results.
            </div>
          )}
        </div>
        {typeof disclosureItems !== "undefined" &&
          disclosureItems.length > 0 &&
          this.props.mode === "regular" && (
            <div className="apply-disclosure-template">
              <Button
                variant="contained"
                color="primary"
                onClick={this.props.onClick}
              >
                <FileCopy /> APPLY RESULTS TO TEMPLATE
              </Button>
            </div>
          )}
        {typeof disclosureItems !== "undefined" &&
          disclosureItems.length > 1 &&
          this.props.mode === "standalone" && (
            <div>
              <img
                alt="disclosure-icon-copy"
                className="disclosure-icon-copy"
                src={copyicon}
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-text")
                }
              />
              <span
                className="copy-all-disclosure"
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-text")
                }
              >
                COPY ALL DISCLOSURE LANGUAGE
              </span>
              &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
              <img
                alt="disclosure-icon-copy"
                className="disclosure-icon-copy"
                src={copyicon}
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-path")
                }
              />
              <span
                className="copy-all-disclosure"
                onClick={() =>
                  this.copyDisclosure("cwbCopyDiclosure", "disclosure-path")
                }
              >
                COPY ALL DMC PATHS
              </span>
            </div>
          )}
        <div id="cwbCopyDiclosure" />
      </div>
    );
  }
}

const mapStateToProps = ({ filters }) => {
  return {
    filters
  };
};

const mapDispatchToProps = dispatch => ({
  generatePdf: payload => dispatch(generatePdf(payload))
});

export default connect(mapStateToProps, mapDispatchToProps)(DisclosureList);
