import React from "react";
import "./../../../assets/scss/options.scss";
import Button from "@material-ui/core/Button";
import CancelIcon from "@material-ui/icons/Cancel";

class FilterButton extends React.Component {
  render() {
    return (
      <React.Fragment>
        {this.props.storeArray &&
          this.props.storeArray.map((items, index) => (
            <Button
              key={index}
              id={items.tagName}
              name={items.tagName}
              variant="contained"
              color="primary"
              classes={{
                root: "classes-state-btn-aud"
              }}
            >
              {items.text}
              {!items.isPercolate && (
                <CancelIcon id={items.tagName} onClick={this.props.onClick} />
              )}
            </Button>
          ))}
      </React.Fragment>
    );
  }
}

export default FilterButton;
