import { Button, Paper, Toolbar, Typography } from "@material-ui/core";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import InfoIcon from "@material-ui/icons/InfoOutlined";
import CWBDialog from "../../Dialog/CWBDialog";
import PropTypes from "prop-types";
import * as R from "ramda";
import React from "react";
import _ from "lodash";
import { connect } from "react-redux";
import { getDisclosureDetails } from "../../../api/disclosureApi";
import checkRight from "../../../assets/images/Disclosure/check-right.svg";
import WarningOutlined from "../../../assets/images/Disclosure/warning-icon.svg";
import DisclosureFAQ from "../../../assets/pdf/CWB-disclosure-faq.pdf";
import { addDisclosureDetails } from "../../../redux/actions/disclosureActions";
import { addTagFilter } from "../../../redux/actions/tagFilterActions";
import {
  STANDARD_TAGS,
  STAND_ALONE_TAGS
} from "../../../redux/constants/standardDisclosuresConstants";
import {
  saveDisclosure,
  updatedisclosureTags
} from "../../../redux/actions/writeAction";
import "../../../shared/scss/Disclosure.css";
import {
  loadPageData,
  recordSearchFacetAnalytics
} from "../../Analytics/Analytics";
import AccordionPanel from "./AccordionPanel";
import DisclosureList from "./DisclosureList";

class Disclosure extends React.Component {
  constructor(props) {
    super(props);
    this.unMounted = false;
    this.state = {
      tagFilterArr: [],
      contextValue: "sc:audience",
      disclosures: [],
      mode: "default",
      alertOpen: false,
      imageIcon: "",
      message: "",
      isLinkPresent: false,
      linkRoute: {},
      confirmation: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.handleResetClick = this.handleResetClick.bind(this);
    this.handleAccordionClick = this.handleAccordionClick.bind(this);
    this.addPercolateTag = this.addPercolateTag.bind(this);
    this.handleApplyToDraft = this.handleApplyToDraft.bind(this);
    this.textCopiedClipboard = this.textCopiedClipboard.bind(this);
    this.handleExpandDefault = this.handleExpandDefault.bind(this);
    this.applyDisclosureOnLoad = this.applyDisclosureOnLoad.bind(this);
    this.handleAlertClose = this.handleAlertClose.bind(this);
    this.selectTag = this.selectTag.bind(this);
  }

  componentWillUnmount() {
    this.unMounted = true;
  }
  componentDidMount() {
    const { assignment } = this.props;
    let standAloneState = JSON.parse(STAND_ALONE_TAGS);

    this.props.addTagFilter(standAloneState);
    this.setState({ tagFilterArr: standAloneState });
    if (
      this.props.location.search &&
      this.props.location.search === "?standalone"
    ) {
      this.setState({ disclosures: [] });
      this.setState({ mode: "standalone" });
    } else {
      let tags = standAloneState;
      if (assignment) {
        tags =
          assignment.taxonomy && !R.isEmpty(assignment.taxonomy)
            ? tags
            : JSON.parse(STANDARD_TAGS);
      }
      if (
        this.props.dataBaseDisclosureTags &&
        typeof this.props.dataBaseDisclosureTags.disclosureTags !==
          "undefined" &&
        this.props.dataBaseDisclosureTags.disclosureTags.length > 0
      ) {
        tags = this.props.dataBaseDisclosureTags.disclosureTags;
      }
      this.addPercolateTag(tags);
      this.applyDisclosureOnLoad(tags);
      
      this.setState({ mode: "regular" });
    }
    loadPageData("Disclosures", "disclosures");
  }
  handleAlertClose() {
    this.setState({ alertOpen: false });
    this.setState({ applyOpen: false });
  }
  handleAccordionClick(e) {
    this.setState({ contextValue: e });
  }
  applyDisclosureOnLoad(tags) {
    let param = "";
    Object.keys(tags).forEach((item, index) => {
      if (index === 0) {
        param = tags[item].parent.replace("sc:", "") + "=";
      } else {
        param = param + "&" + tags[item].parent.replace("sc:", "") + "=";
      }
      tags[item].child.forEach((items, index) => {
        if (index === 0) {
          param = param + items.tagName;
        } else {
          param = param + "," + items.tagName;
        }
      });
    });
    getDisclosureDetails(param)
      .then(results => {
        return results;
      })
      .then(dataValues => {
        !this.unMounted && this.setState({ disclosures: dataValues.data });
      })
      .catch(err => console.error(err));
  }

  handleClick() {
    if (
      this.props.tagFilter &&
      this.props.tagFilter[0].child.length > 0 &&
      this.props.tagFilter[1].child.length > 0
    ) {
      let param = "";
      let Facetparam = "";
      Object.keys(this.props.tagFilter).forEach((item, index) => {
        if (index === 0) {
          param = this.props.tagFilter[item].parent.replace("sc:", "") + "=";
        } else {
          param =
            param +
            "&" +
            this.props.tagFilter[item].parent.replace("sc:", "") +
            "=";
        }
        this.props.tagFilter[item].child.forEach((items, index) => {
          if (index === 0) {
            param = param + items.tagName;
            Facetparam = Facetparam + items.tagName;
          } else {
            param = param + "," + items.tagName;
            Facetparam = Facetparam + "," + items.tagName;
          }
        });
        Facetparam = Facetparam + ";";
      });
      getDisclosureDetails(param)
        .then(results => {
          return results;
        })
        .then(dataValues => {
          !this.unMounted && this.setState({ disclosures: dataValues.data });
          recordSearchFacetAnalytics(
            "disclosures",
            dataValues.data.length,
            Facetparam,
            "disclosures"
          );
        })
        .catch(err => console.error(err));
    } else {
      this.setState({
        alertOpen: true,
        imageIcon: WarningOutlined,
        message: `Audience and Channel are required.<br/><br/>
      <b>You cannot continue until you select at<br/>least one tag for each required field.</b><br/>`,
        isLinkPresent: false
      });
    }
  }

  selectTag() {
    this.setState({
      alertOpen: true,
      imageIcon: WarningOutlined,
      message: `Please Select Tag`
    });
  }

  addPercolateTag(standAloneState) {
    let updateArr = standAloneState;
    if (
      this.props.dataBaseDisclosureTags &&
      typeof this.props.dataBaseDisclosureTags.disclosureTags !== "undefined" &&
      this.props.dataBaseDisclosureTags.disclosureTags.length > 0
    ) {
      updateArr = this.props.dataBaseDisclosureTags.disclosureTags;
    }
    let percolateTagArr =
      this.props.assignment && this.props.assignment.taxonomy;
    this.props.assignment &&
      percolateTagArr &&
      Object.keys(this.props.assignment.taxonomy).forEach(items => {
        updateArr.forEach(a => {
          if (items.includes(a.parent.replace("sc:", ""))) {
            percolateTagArr[items].forEach((tag, index) => {
              let arrayIndex = a.child.findIndex(
                i => i.tagName.toUpperCase() === tag.toUpperCase()
              );
              if (arrayIndex === -1) {
                let tempArr = { text: tag, isPercolate: true, tagName: tag };
                a.child = a.child.concat(tempArr);
              }
            });
          }
        });
      });

    const standardTags = JSON.parse(STANDARD_TAGS);
    updateArr.forEach(arrTag => {
      if (arrTag.child && arrTag.child.length) {
        return;
      }
      standardTags.forEach(tag => {
        if (arrTag.parent === tag.parent) {
          arrTag.child = _.cloneDeep(tag.child);
        }
      });
    });

    this.setState({ tagFilterArr: updateArr });
    this.props.addTagFilter(updateArr);
    this.forceUpdate();
  }

  handleResetClick() {
    let resetState = [
      { parent: "sc:audience", title: "Audience*", child: [] },
      { parent: "sc:channel", title: "Channel*", child: [] },
      { parent: "sc:product", title: "Product", child: [] },
      { parent: "sc:feeStructure", title: "Fee Structure", child: [] },
      { parent: "sc:statistic", title: "Statistic", child: [] },
      {
        parent: "sc:feeStructureCharacteristic",
        title: "Fee Structure Characteristic",
        child: []
      },
      {
        parent: "sc:materialCharacteristic",
        title: "Material Characteristic",
        child: []
      },
      {
        parent: "sc:productCharacteristic",
        title: "Product Characteristic",
        child: []
      },
      { parent: "sc:general", title: "General", child: [] }
    ];
    if (this.state.mode === "regular") {
      let percolateTagArr = this.props.assignment.taxonomy;
      percolateTagArr &&
        Object.keys(percolateTagArr).forEach(items => {
          resetState.forEach(a => {
            if (items.includes(a.parent.replace("sc:", ""))) {
              percolateTagArr[items].forEach(tag => {
                let arrayIndex = a.child.findIndex(
                  i => i.tagName.toUpperCase() === tag.toUpperCase()
                );
                if (arrayIndex === -1) {
                  let tempArr = { text: tag, isPercolate: true, tagName: tag };
                  a.child = a.child.concat(tempArr);
                }
              });
            }
          });
        });
    }
    this.props.addTagFilter(resetState);
    this.setState({ tagFilterArr: resetState });
    this.setState({ disclosures: [] });
    this.forceUpdate();
  }

  handleApplyToDraft() {
    if (this.state.disclosures.hasOwnProperty("Results")) {
      this.props.addDisclosureDetails(this.state.disclosures);
    }
    this.props.updatedisclosureTags(this.props.tagFilter);
    this.setState({
      linkRoute: {
        to: "/write",
        message: `Show me in the template`
      },
      alertOpen: true,
      imageIcon: checkRight,
      message: `Your disclosure was applied.`,
      isLinkPresent: true
    });
  }

  textCopiedClipboard() {
    this.setState({
      alertOpen: true,
      imageIcon: checkRight,
      message: `Text Copied`
    });
  }

  handleExpandDefault(child) {
    let flag = false;
    if (child.length > 0) {
      flag = true;
    }
    return Boolean(flag);
  }

  render() {
    const {
      imageIcon,
      message,
      alertOpen,
      isLinkPresent,
      linkRoute
    } = this.state;
    if (this.props.write && R.isEmpty(this.props.write.write))
      this.props.history.push("/");
    return (
      <div>
        {
          <CWBDialog
            open={alertOpen}
            onClose={this.handleAlertClose}
            imageIcon={imageIcon}
            message={message}
            isLinkPresent={isLinkPresent}
            linkRoute={linkRoute}
            customClass={`disclosure-alert-dialog`}
          />
        }
        <Toolbar className={"tab-header"}>
          <Typography variant="title">
            <InfoIcon />
            Disclosure
          </Typography>
        </Toolbar>
        <div className="Search-for-related-d">
          Filter by categories to get the disclosures and rendition paths for
          your project.
        </div>
        <Paper>
          <Typography variant="title" className={"mod-header"}>
            Disclosure Search
            <Button
              className="disclosure-faq"
              href={DisclosureFAQ}
              target="_blank"
            >
              How to use the Disclosure Tool
            </Button>
          </Typography>
          <div className="content-block">
            <div className="disclosure-box">
              <div className="disclosure-tags-control">
                {this.state.tagFilterArr &&
                  this.state.tagFilterArr.map((items, index) => (
                    <ExpansionPanel
                      key={items.parent}
                      onClick={() => this.handleAccordionClick(items.parent)}
                      defaultExpanded={this.handleExpandDefault(items.child)}
                      className={"disclosure-category-container"}
                    >
                      <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        className={"disclosure-category"}
                      >
                        {items.title
                          ? items.title
                          : items.parent
                              .toString()
                              .replace("sc:", "")
                              .toLowerCase()
                              .split(" ")
                              .map(
                                s => s.charAt(0).toUpperCase() + s.substring(1)
                              )
                              .join(" ")}
                      </ExpansionPanelSummary>
                      <ExpansionPanelDetails
                        className={"disclosure-category-details"}
                      >
                        <AccordionPanel
                          parentId={items.parent}
                          title={items.title}
                          addTag={this.selectTag}
                        />
                      </ExpansionPanelDetails>
                    </ExpansionPanel>
                  ))}
                <div className={"disclosure-actions-box"}>
                  <Button
                    variant="contained"
                    className="disclosure-reset"
                    onClick={this.handleResetClick}
                  >
                    Reset
                  </Button>
                  <Button
                    variant="contained"
                    className="disclosure-apply"
                    onClick={this.handleClick}
                  >
                    Apply
                  </Button>
                </div>
              </div>
              <div className="disclosure-results">
                <div className="row">
                  <p className="Disclosure-Analyzer">Results</p>
                </div>
                <div className="disclosure-list-block">
                  <DisclosureList
                    onClick={this.handleApplyToDraft}
                    textCopied={this.textCopiedClipboard}
                    disclosure={this.state.disclosures}
                    mode={this.state.mode}
                  />
                </div>
              </div>
            </div>
          </div>
        </Paper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    loading: state.disclosures.loading,
    disclosure: state.disclosures.disclosure,
    error: state.disclosures.error,
    tagFilter: state.filters.tagFilter,
    assignment: state.assignments && state.assignments.assignment,
    write: state.write,
    dataBaseDisclosureTags: state.write.write && state.write.write.assignment
  };
};

const mapDispatchToProps = dispatch => ({
  addDisclosureDetails: param => dispatch(addDisclosureDetails(param)),
  addTagFilter: name => dispatch(addTagFilter(name)),
  updatedisclosureTags: tags => dispatch(updatedisclosureTags(tags)),
  saveDisclosure: disclosure => dispatch(saveDisclosure(disclosure))
});

Disclosure.propTypes = {
  addDisclosureDetails: PropTypes.func.isRequired,
  addTagFilter: PropTypes.func.isRequired,
  updatedisclosureTags: PropTypes.func.isRequired
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Disclosure);
