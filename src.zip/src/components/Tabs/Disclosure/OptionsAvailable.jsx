import React, { Component } from "react";
import { Button } from "reactstrap";
import "./../../../assets/scss/options.css";
import CancelCircleIcon from "@material-ui/icons/CancelOutlined";
import AddCircleIcon from "@material-ui/icons/AddCircleOutline";
import ArrowBackWardIcon from "@material-ui/icons/ArrowBack";
import ArrowForwardIcon from "@material-ui/icons/ArrowForward";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import ToggleChild from "./ToggleChild";
import { addTagFilter } from "../../../redux/actions/tagFilterActions";
import FolderIcon from "@material-ui/icons/Folder";

class OptionsAvailable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tagArr: { data: [{}] },
      appliedTagArr: [],
      tempTag: [],
      tempAppliedTag: []
    };

    this.tagSelected = this.tagSelected.bind(this);
    this.handleAddClick = this.handleAddClick.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleAddAppliedTag = this.handleAddAppliedTag.bind(this);
    this.handleDeleteAppliedTag = this.handleDeleteAppliedTag.bind(this);
    this.appliedTag = this.appliedTag.bind(this);
    this.appliedTagSelected = this.appliedTagSelected.bind(this);
    this.handleModalSave = this.handleModalSave.bind(this);
    this.compare = this.compare.bind(this);
  }

  tagSelected(e) {
    if (e.target.id && e.target.tagName.toLowerCase() === "span") {
      document.getElementById(e.target.id).classList.toggle("tag-active");
    }
    let index =
      this.state.tempTag &&
      this.state.tempTag.findIndex(
        x => x.tagName === e.target.getAttribute("name")
      );

    if (index > -1) {
      this.state.tempTag.splice(index, 1);
    } else {
      e.target.getAttribute("name") !== null &&
        this.state.tempTag.push({
          text: e.target.title,
          tagName: e.target.getAttribute("name")
        });
    }
  }

  handleModalSave() {
    let modalTagArray = this.state.appliedTagArr;
    let updateArr = this.props.tagArray;
    let parentContext = this.props.contextValue;
    updateArr.forEach(function iter(a) {
      if (parentContext.includes(a.parent)) {
        a.child = [];
        modalTagArray.forEach((item, index) => {
          if (index === 0) {
            a.child[0] = {
              text: item.text,
              isPercolate: item.isPercolate,
              tagName: item.tagName
            };
          } else {
            a.child = a.child.concat({
              text: item.text,
              isPercolate: item.isPercolate,
              tagName: item.tagName
            });
          }
        });
      }
    });

    this.props.addTagFilter(updateArr);
    this.props.onClick();
  }

  compare(a, b) {
    // Use toUpperCase() to ignore character casing
    const tagTextA = a.text.toUpperCase();
    const tagTextB = b.text.toUpperCase();

    let comparison = 0;
    if (tagTextA > tagTextB) {
      comparison = 1;
    } else if (tagTextA < tagTextB) {
      comparison = -1;
    }
    return comparison;
  }

  handleAddClick(e) {
    if (
      e.target.parentElement.id !== "undefined" &&
      e.target.parentElement.id !== ""
    ) {
      let constructedUrl =
        "/bin/scs/fetchdriversmodifiers?parentid=" + e.target.parentElement.id;
      let parentNode = "ul_" + e.target.parentElement.id;
      if (document.getElementById(parentNode)) {
        document.getElementById(parentNode).classList.toggle("active");
        if (document.getElementById(parentNode).childElementCount === 0) {
          fetch(constructedUrl, {
            method: "GET",
            mode: "cors",
            headers: {
              Accept: "application/json"
            }
          })
            .then(results => {
              if (results.ok) {
                return results.json();
              } else {
                throw new Error(
                  "Unable to get response from API, may be AEM is down"
                );
              }
            })
            .then(dataValues => {
              typeof dataValues.data !== "undefined" &&
                dataValues.data.sort(this.compare).forEach(tag => {
                  let li = document.createElement("li");
                  li.setAttribute("class", "disclosure-sub-option-text");
                  li.setAttribute("onClick", this.tagSelected);
                  li.innerHTML =
                    "<span id='span_" +
                    tag.tagName +
                    "' title='" +
                    tag.text +
                    "' name='" +
                    tag.tagName +
                    "'>" +
                    tag.text +
                    "</span>";
                  document.getElementById(parentNode).appendChild(li);
                });
            })
            .catch(error => {
              console.error(error);
            });
        }
      }
    }
  }

  handleClose() {
    this.props.open = false;
  }

  appliedTagSelected(e) {
    if (e.target.id && e.target.tagName.toLowerCase() === "span") {
      document.getElementById(e.target.id).classList.toggle("tag-active");
    }
    let index =
      this.state.tempAppliedTag &&
      this.state.tempAppliedTag.findIndex(
        x => x.tagName === e.target.getAttribute("name")
      );

    if (index > -1) {
      this.state.tempAppliedTag.splice(index, 1);
    } else {
      this.state.tempAppliedTag.push({
        text: e.target.title,
        tagName: e.target.getAttribute("name")
      });
    }
  }

  handleAddAppliedTag() {
    this.state.appliedTagArr &&
      this.state.tempTag &&
      this.state.tempTag.forEach((tag, index) => {
        document.getElementById("span_" + tag.tagName) &&
          document
            .getElementById("span_" + tag.tagName)
            .classList.remove("tag-active");
        if (
          tag &&
          this.state.appliedTagArr.findIndex(
            i => i.tagName.toUpperCase() === tag.tagName.toUpperCase()
          ) === -1
        ) {
          this.state.appliedTagArr.push({
            text: tag.text,
            isPercolate: false,
            tagName: tag.tagName
          });
        }
      });
    this.setState({ tempTag: [] });
    this.setState({ tempAppliedTag: [] });

    this.forceUpdate();
  }

  handleDeleteAppliedTag() {
    this.state.appliedTagArr &&
      this.state.tempAppliedTag &&
      this.state.tempAppliedTag.forEach(tag => {
        document.getElementById("applied_span_" + tag.tagName) &&
          document
            .getElementById("applied_span_" + tag.tagName)
            .classList.remove("tag-active");
        var index = "";
        index = this.state.appliedTagArr.findIndex(
          i => i.tagName === tag.tagName
        );
        if (index > -1) {
          this.state.appliedTagArr.splice(index, 1);
        }
      });
    this.setState({ tempTag: [] });
    this.setState({ tempAppliedTag: [] });

    this.forceUpdate();
  }

  appliedTag() {
    let newArray = [];
    Object.keys(this.props.tagArray).forEach(item => {
      if (this.props.tagArray[item].parent === this.props.contextValue) {
        this.props.tagArray[item].child.forEach(items => {
          newArray.push(items);
        });
      }
      this.setState({ appliedTagArr: newArray });
    });
  }

  componentDidMount() {
    if (this.props.contextValue !== "") {
      let constructedUrl =
        "/bin/scs/fetchdriversmodifiers?parentid=" + this.props.contextValue;
      fetch(constructedUrl, {
        method: "GET",
        mode: "cors",
        headers: {
          Accept: "application/json"
        }
      })
        .then(results => {
          return results && results.json();
        })
        .then(dataValues => {
          this.setState({ tagArr: dataValues });
        });
    }

    this.appliedTag();
  }

  render() {
    return (
      <div className="row options disclosure-config-columns">
        <div className="col-md-5 options-available">
          <div>
            <h3>Options Available</h3>
          </div>
          <div className="options-list">
            <ul>
              <li
                className="tag-tree-view"
                href="#"
                color="primary"
                style={{ marginBottom: "1rem" }}
              >
                {this.props.contextTitle}
                <ul className="tag-tree-view options-item-block">
                  {this.state.tagArr &&
                    this.state.tagArr.data
                      .sort(this.compare)
                      .map((tag, index) => (
                        <li
                          key={index}
                          id={tag.tagid}
                          onClick={this.tagSelected}
                          className="tag-tree-view"
                          title={tag.text}
                          name={tag.tagName}
                          color="primary"
                          style={{ marginBottom: "1rem" }}
                        >
                          <ToggleChild
                            onClick={this.handleAddClick}
                            id={tag.tagid}
                          />
                          <span
                            id={"span_" + tag.tagName}
                            title={tag.text}
                            name={tag.tagName}
                            className="disclosure-option-text"
                          >
                            {tag.text}
                          </span>
                          <ul id={"ul_" + tag.tagid} className="nested" />
                        </li>
                      ))}
                </ul>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-md-2 options-actions">
          <Button
            variant="contained"
            color="primary"
            onClick={this.handleAddAppliedTag}
          >
            Add <ArrowForwardIcon />
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={this.handleDeleteAppliedTag}
          >
            <ArrowBackWardIcon />
            Delete
          </Button>
        </div>
        <div className="col-md-5 options-applied">
          <div>
            <h3>Options Applied</h3>
          </div>
          <div className="options-list">
            <ul className="tag-tree-view options-item-block">
              {this.state.appliedTagArr &&
                this.state.appliedTagArr.sort().map((items, index) => (
                  <li className="disclosure-option-text" key={index}>
                    <FolderIcon />
                    <span
                      className="disclosure-option-text"
                      onClick={this.appliedTagSelected}
                      key={index}
                      name={items.tagName}
                      id={"applied_span_" + items.tagName}
                      title={items.text}
                      color="primary"
                      style={{ marginBottom: "1rem" }}
                    >
                      {items.text
                        .toLowerCase()
                        .split(" ")
                        .map(s => s.charAt(0).toUpperCase() + s.substring(1))
                        .join(" ")}
                    </span>
                  </li>
                ))}
            </ul>
          </div>
        </div>
        <div className="options-btns">
          <Button
            variant="contained"
            color="primary"
            onClick={this.props.onClick}
            classes={{
              root: "classes-state-root-btn-cancel"
            }}
          >
            <CancelCircleIcon />
            Cancel
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={this.handleModalSave}
          >
            <AddCircleIcon />
            Save
          </Button>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    tagArray: state.filters.tagFilter
  };
};
const mapDispatchToProps = dispatch => ({
  addTagFilter: name => dispatch(addTagFilter(name))
});

OptionsAvailable.propTypes = {
  addTagFilter: PropTypes.func.isRequired
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OptionsAvailable);
