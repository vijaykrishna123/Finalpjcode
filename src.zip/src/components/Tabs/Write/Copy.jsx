import Grid from "@material-ui/core/Grid";
import React, { useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as copy_actions from "../../../redux/actions/writeAction";
import "./../../../assets/scss/write.css";
import CopyItem from "./CopyItem";
import SectionHeader from "./SectionHeader";
import Button from "@material-ui/core/Button";
import ReviewIcon from "@material-ui/icons/Done";
import InfoIcon from "@material-ui/icons/InfoOutlined";
import { uploadCopyFormData } from "../../../redux/actions/writeAction";
import { withStyles } from "@material-ui/core/styles";
import ReviewDialog from "./ReviewDialog";
import BackupIcon from "@material-ui/icons/Backup";
import ShareIcon from "@material-ui/icons/Share";

const styles = theme => ({
  templateContainer: {
    display: "flex",
    justifyContent: "space-between",
    "& button": {
      float: "none !important",
      width: "auto !important",
      height: "auto !important",
      padding: "5px 15px !important",
      background: "transparent",
      border: "solid 2px rgba(255, 255, 255, 0.5);",
      color: "#fff",
      fontWeight: " bold",
      "&:hover": {
        background: "transparent",
        border: "solid 2px rgba(255, 255, 255, 0.5);",
        color: "#fff"
      }
    }
  },
  shareBtn: {
    border: "none !important",
    boxShadow: "none"
  },
  saveWork: {
    margin: "0 10px !important",
    backgroundColor: " #b42573 !important"
  },
  helper: {
    fontSize: "14px",
    color: "#005f9e",
    fontWeight: "600",
    "&:hover": {
      color: "#005f9e",
      fontWeight: "600"
    }
  },
  textSpace: {
    marginLeft: 10
  }
});

function Copy(props) {
  const { classes, copy, userDetails, write, shareUrl } = props;
  const value =
    write && (write.showCreateReviewModal || write.showLegalReviewModal)
      ? true
      : false;

  const [dialog, setDialog] = useState(value);
  const [openBar, setOpenBar] = useState(false);
  const [message, setMessage] = useState("");
  const [variant, setVariant] = useState("");

  if (!copy || !copy.copy) return null;

  const onDialogClose = () => {
    setDialog(false);
  };
  const saveInStore = payload => {
    props.updateCopyRequest(payload);
  };

  const showMessage = (message, variant) => {
    setMessage(message);
    setVariant(variant);
    setOpenBar(true);
  };

  const saveClicked = event => {
    event.preventDefault();
    // Create the event
    let customEvent = new CustomEvent("save-clicked", { bubbles: true });
    // Dispatch/Trigger/Fire the event
    document.dispatchEvent(customEvent);
  };

  const saveTheForm = (editor, id) => {
    props.updateCopyRequest({ [id]: editor.getData() });
    props.uploadCopyFormData({ formData: props.copy });
  };

  return (
    <div className={"write-copy-block"}>
      <Grid container direction="row" justify="center" alignItems="center">
        <Grid xs={12} item={true}>
          <SectionHeader
            title={
              <div className={classes.templateContainer}>
                <span>
                  {copy.assignment && copy.assignment.templateName} Template
                </span>
                <div>
                  <Button
                    className={`${classes.button} ${classes.shareBtn}`}
                    onClick={shareUrl}
                  >
                    <ShareIcon /> SHARE/NOTIFY
                  </Button>
                  <Button
                    variant="contained"
                    className={classes.saveWork}
                    onClick={saveClicked}
                  >
                    <BackupIcon />
                    <span className={classes.textSpace}>SAVE WORK </span>
                  </Button>
                  <Button
                    variant="contained"
                    disabled={copy.assignment && copy.assignment.stateId == 4}
                    className={classes.link}
                    onClick={() => setDialog(true)}
                  >
                    <ReviewIcon />
                    <span className={classes.textSpace}>
                      Review & Create PDF
                    </span>
                  </Button>
                </div>
              </div>
            }
            id="copy"
            noIcon={true}
          />

          <ReviewDialog
            onClose={onDialogClose}
            open={dialog}
            isDone={false}
            openBar={openBar}
            message={message}
            variant={variant}
            showMessage={showMessage}
            closeBarHandler={setOpenBar}
          />
          <div className={"mod-content research-assignment-grid"}>
            <div>
              <Grid item xs={12}>
                <u>
                  <a
                    className={classes.helper}
                    href="https://confluence.capgroup.com/pages/viewpage.action?spaceKey=NGM&title=CWB+-+Template+Help"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <InfoIcon /> Need help with these fields? Visit the wiki for
                    more information.
                  </a>
                </u>
              </Grid>
            </div>
            <CopyItem
              type={copy.assignment.templateName}
              isReadOnly={copy.assignment.stateId === 4}
              fieldProps={copy.copy}
              onCommentBtnClick={() => {}}
              saveInStore={saveInStore}
              userId={userDetails.userId}
              assignmentId={copy.assignment.id}
              saveForm={saveTheForm}
              postId={copy.assignment.percolateId}
            />
          </div>
        </Grid>
      </Grid>
    </div>
  );
}

const mapStateToProps = ({ write, user }) => {
  return {
    write: write,
    copy: write.write,
    userDetails: user
  };
};
const mapDispatchToProps = dispatch => {
  return {
    ...bindActionCreators(copy_actions, dispatch),
    ...bindActionCreators(uploadCopyFormData, dispatch)
  };
};
const ConnectedComponent = connect(mapStateToProps, mapDispatchToProps)(Copy);
export default withStyles(styles)(ConnectedComponent);
