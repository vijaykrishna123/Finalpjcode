import { Paper, Typography } from "@material-ui/core";
import HelpIcon from "@material-ui/icons/Help";
import React from "react";
import Popup from "reactjs-popup";

const Tooltips = props => (
  <Popup
    trigger={<HelpIcon />}
    position="right top"
    on="hover"
    closeOnDocumentClick
  >
    <span dangerouslySetInnerHTML={{ __html: props.content }} />
  </Popup>
);

function SectionHeader(props) {
  const { title = "" } = props;
  return (
    <div>
      <Paper className={"section-header"}>
        <Typography component="h2" variant="h5" className={"mod-header"}>
          {title}
        </Typography>
        {props.tooltip && <Tooltips content={props.tooltip} />}
      </Paper>
    </div>
  );
}

export default SectionHeader;
