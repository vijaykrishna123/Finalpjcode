import React from "react";
import { withStyles } from "@material-ui/core/styles";
import { Button, Dialog, DialogContent, IconButton } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";

const style = theme => ({
  DialogContent: {
    padding: "60px 70px 40px !important",
    textAlign: "center"
  },
  cancelBtn: {
    marginRight: "10px",
    color: "#005f9e",
    borderColor: "#005f9e"
  },
  goToButton: {
    margin: 0,
    backgroundColor: "#005f9e",
    color: "#fff",
    "&:hover": {
      backgroundColor: "#005f9e"
    }
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing.unit,
    top: theme.spacing.unit,
    color: theme.palette.grey[500]
  }
});

const WriteProofModal = props => {
  const { classes, open, onProofModalClose, assignment, proofURL } = props;
  return (
    <Dialog open={open}>
      <DialogContent className={classes.DialogContent}>
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onProofModalClose}
        >
          <CloseIcon />
        </IconButton>
        <div>You are viewing </div>
        <div>
          <strong>{assignment ? assignment.name : null}</strong>
        </div>
        <br />
        <Button
          variant="outlined"
          className={classes.cancelBtn}
          onClick={onProofModalClose}
        >
          GO TO PROJECT
        </Button>
        <Button
          variant="contained"
          href={proofURL}
          target="_blank"
          className={classes.goToButton}
        >
          GO TO PROOF
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default withStyles(style)(WriteProofModal);
