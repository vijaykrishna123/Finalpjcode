import React from "react";
import { Grid, withStyles, Dialog, Typography } from "@material-ui/core";
import IconButton from "@material-ui/core/IconButton";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import CloseIcon from "@material-ui/icons/Close";
import MuiDialogContent from "@material-ui/core/DialogContent";
import configDeterminator from "../../../configs/configDeterminator";
import BackUps from "../Review&Submit/Back_Ups";
import Summary from "../Review&Submit/Summary";
import { connect } from "react-redux";
import ReviewSubmit from "../Review&Submit/ReviewSubmit";
import Snackbar from "@material-ui/core/Snackbar";
import { CWBSnackbarContentWrapper } from "../../Popups/CWBSnackBar";

import Download from "@material-ui/icons/GetApp";

const styles = () => ({
  paperScrollPaper: {
    maxHeight: 800,
    maxWidth: 1580,
    height: 699,
    width: 1380
  },
  reviewContent: {
    height: 600,
    overflowY: "scroll"
  },
  savePDF: {
    paddingLeft: 20
  },
  anchorTag: {
    color: "#005f9e !important",
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Demi !important"
  },
  zipDesc: {
    color: "#666666",
    fontSize: "14px !important",
    fontFamily: "AvenirNextLT-Regular !important",
    marginLeft: "30px"
  }
});

const DialogTitle = withStyles(theme => ({
  root: {
    borderBottom: `1px solid ${theme.palette.divider}`,
    margin: 0,
    padding: theme.spacing.unit * 2,
    backgroundColor: " #e5e5e5"
  },
  header: {
    fontFamily: "AvenirNextLT-Demi",
    fontSize: "18px",
    fontWeight: "600",
    fontStyle: "normal",
    fontStretch: "normal",
    lineHeight: "normal",
    letterSpacing: "normal",
    color: " #000000"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing.unit,
    top: theme.spacing.unit,
    color: theme.palette.grey[500]
  }
}))(props => {
  const { children, classes, onClose } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root}>
      <Typography variant="h6" className={classes.header}>
        {children}
      </Typography>

      <IconButton
        aria-label="Close"
        className={classes.closeButton}
        onClick={onClose}
      >
        <CloseIcon />
      </IconButton>
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles(theme => ({
  root: {
    margin: 0,
    padding: theme.spacing.unit * 2
  }
}))(MuiDialogContent);

const CustomizedDialogDemo = ({
  open,
  classes,
  onClose,
  assignment,
  writes,
  handleClose,
  isDone,
  openBar,
  message,
  variant,
  showMessage,
  closeBarHandler
}) => {
  handleClose = () => {
    this.setState({ open: false });
  };
  // const downloadDoc = () => {
  //   const preHtml =
  //     "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>Export HTML To Doc</title></head><body>";
  //   const postHtml = "</body></html>";
  //   const html =
  //     preHtml + document.getElementById("content-block").innerHTML + postHtml;
  //   const blob = new Blob(["\ufeff", html], {
  //     type: "application/msword"
  //   });
  //   const url =
  //     "data:application/vnd.ms-word;charset=utf-8," + encodeURIComponent(html);
  //   let filename = "";
  //   if (
  //     writes &&
  //     writes.write &&
  //     writes.write.assignment &&
  //     writes.write.assignment.assignmentName
  //   ) {
  //     filename = writes.write.assignment.assignmentName;
  //   }
  //   filename = filename ? filename + ".doc" : "document.doc";
  //   const downloadLink = document.createElement("a");
  //   document.body.appendChild(downloadLink);
  //   if (navigator.mssaveOrOpenBlob) {
  //     navigator.msSaveOrOpenBlob(blob, filename);
  //   } else {
  //     downloadLink.href = url;
  //     downloadLink.download = filename;
  //     downloadLink.click();
  //   }
  //   document.body.removeChild(downloadLink);
  // };

  if (!assignment) return null;
  return (
    <div>
      <Dialog
        onClose={onClose}
        aria-labelledby="customized-dialog-title"
        open={open}
        classes={{ paperScrollPaper: classes.paperScrollPaper }}
      >
        <DialogTitle id="customized-dialog-title" onClose={onClose}>
          Review & submit/output
        </DialogTitle>

        <DialogContent>
          <div className="review-block">
            <Snackbar
              anchorOrigin={{
                vertical: "top",
                horizontal: "right"
              }}
              open={openBar}
              autoHideDuration={4000}
              onClose={() => closeBarHandler(false)}
            >
              <CWBSnackbarContentWrapper
                onClose={() => closeBarHandler(false)}
                variant={variant}
                message={message}
              />
            </Snackbar>

            <Grid container>
              <Grid
                xs={9}
                item={true}
                className={classes.reviewContent + " review-draft-block"}
              >
                <div className="content-block" id="content-block">
                  {writes.write.copy && (
                    <Summary
                      data={writes.write.copy}
                      type={writes.write.assignment.templateName}
                    />
                  )}

                  {writes.write.backups && (
                    <BackUps data={writes.write.backups} />
                  )}

                  {writes.write.graphics && (
                    <BackUps
                      data={writes.write.graphics}
                      title="Creative assets"
                      subUrl="graphics"
                      urlKey="graphicsId"
                    />
                  )}
                </div>
              </Grid>
              <Grid xs={3} item={true} className={classes.savePDF}>
                <Grid xs={12} item={true}>
                  <ReviewSubmit showMessage={showMessage} />
                </Grid>

                <br />
                <Grid xs={12} item={true}>
                  <a
                    color="primary"
                    data-analytics-placement="litDownload : body"
                    data-analytics-label={
                      assignment && assignment.template + "|pdf: trackDownload"
                    }
                    data-analytics-id={
                      assignment &&
                      assignment.name
                        .replace(/ /g, "_")
                        .replace(/[^a-zA-Z0-9_]/g, "") + ".pdf|:Download"
                    }
                    href={
                      configDeterminator.cwbApiEndpoint +
                      "/generate/" +
                      assignment.id +
                      "?fileType=pdf"
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`${classes.anchorTag} anchor-tag`}
                  >
                    <Download />
                    Preview PDF
                  </a>
                </Grid>

                <Grid xs={12} item={true}>
                  <a
                    color="primary"
                    data-analytics-placement="litDownload : body"
                    data-analytics-label={
                      assignment && assignment.template + "|zip: trackDownload"
                    }
                    data-analytics-id={
                      assignment &&
                      assignment.name
                        .replace(/ /g, "_")
                        .replace(/[^a-zA-Z0-9_]/g, "") + ".zip|:Download"
                    }
                    href={
                      configDeterminator.cwbApiEndpoint +
                      "/generate/" +
                      assignment.id +
                      "?fileType=zip"
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`${classes.anchorTag} anchor-tag`}
                  >
                    <Download />
                    Download ZIP
                  </a>
                  <div className={classes.zipDesc}>
                    Zip file downloads the .pdf, image files, and backup for
                    your project.
                    <br />
                    <strong>
                      Before downloading, please upload any images to the
                      Creative Assets section.
                    </strong>
                  </div>

                  {/*</Grid> <Grid xs={12} item={true}>
                    <Button
                      variant="contained"
                      onClick={downloadDoc}
                      target="_blank"
                      className={"btn-large btn-solid-blue"}
                    >
                      Download Docs
                    </Button>
                  </Grid> */}
                </Grid>
              </Grid>
            </Grid>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
const mapStateToProps = ({ write, assignments }) => {
  return {
    writes: write,
    assignment: assignments.assignment
  };
};

export default withStyles(styles)(
  connect(mapStateToProps)(CustomizedDialogDemo)
);
