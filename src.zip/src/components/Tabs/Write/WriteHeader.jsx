import React, { Fragment } from "react";
import { Toolbar, Typography } from "@material-ui/core";
import ArrowForward from "@material-ui/icons/ArrowForward";
import WriteIcon from "@material-ui/icons/Create";

const WriteHeader = props => {
  const { classes, write, states } = props;
  if (!write || !write.assignment) {
    return null;
  }
  return (
    <Toolbar className={"tab-header " + classes.container}>
      <Typography variant="title">
        <WriteIcon />
        Write
      </Typography>
      <div>
        {states.map(state => {
          if (state.id <= 1 || state.id > 4) return null;
          return (
            <Fragment key={state.id}>
              <span
                className={`${classes.headerTag} ${
                  write.assignment.stateId === state.id
                    ? ""
                    : classes.headerTagDisabled
                }`}
              >
                {state.stateName}
              </span>
              {state.id === 4 ? null : (
                <ArrowForward
                  style={{ color: "#fff" }}
                  className={`${classes.headerTagDisabled} ${classes.margin10}`}
                />
              )}
            </Fragment>
          );
        })}
      </div>
    </Toolbar>
  );
};

export default WriteHeader;
