import React, { useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as backups_actions from "../../../../redux/actions/writeAction";
import { withStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import FormField from "../../../Form/FormField/FormField";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import configDeterminator from "../../../../configs/configDeterminator";
import DeleteIcon from "@material-ui/icons/Delete";
import DownloadIcon from "@material-ui/icons/GetApp";
import CWBDialog from "../../../Dialog/CWBDialog";

const styles = theme => {
  return {
    grid: {
      display: "flex",
      flex: 1,
      alignItems: "center",
      margin: "10px"
    },
    blockquote: {
      borderLeft: "4px solid #cbd0d2",
      paddingLeft: "10px",
      color: "#17a2b8",
      fontWeight: "100"
    },
    uploadFile: {
      marginBottom: "20px"
    },
    disabled: {
      backgroundColor: "#ccccc"
    }
  };
};

const ResponsiveImageItem = React.memo(function ResponsiveImageItem(props) {
  const [open, setOpen] = useState(false);
  const onClose = confirm => {
    if (confirm === "yes") {
      const { graphicId } = props;
      props.deleteGraphicRequest({ graphicId });
    } else {
      console.log("Ok, We will not delete");
    }
    setOpen(false);
  };

  const handleDeleteBackupItem = () => {
    setOpen(true);
  };

  const renderBackupItem = () => {
    const { classes, name, graphicId, isReadOnly } = props;
    return (
      <Card className={"write-backup-card"}>
        <CardHeader
          className={"write-backup-card-hdr"}
          title="Image file"
          action={
            <div className={"backup_card_buttons"}>
              <Button
                onClick={handleDeleteBackupItem}
                color="primary"
                disabled={!name || isReadOnly}
              >
                <DeleteIcon color={name ? "primary" : "disabled"} />
              </Button>
              <Button
                color="primary"
                target="_blank"
                href={`${configDeterminator.cwbApiEndpoint}/graphics/${graphicId}`}
                disabled={!name || isReadOnly}
              >
                <DownloadIcon color={name ? "primary" : "disabled"} />
              </Button>
            </div>
          }
        />
        <CardContent className={"write-backup-card-file"}>
          <div className={classes.uploadFile}>
            <FormField
              isReadOnly={isReadOnly}
              id={graphicId}
              label={"Browse"}
              allowComments={false}
              fieldType="FileUpload"
              value={name}
            />
          </div>
        </CardContent>
      </Card>
    );
  };

  const { classes, isList } = props;
  return (
    <Grid
      item
      className={isList ? "backups-flat-list" : `backup-card ${classes.grid}`}
    >
      <CWBDialog
        open={open}
        onClose={onClose}
        confirmation={true}
        message={`Are you sure you want to delete?<br /><br />`}
        customClass={`delete-dialog`}
      />
      {renderBackupItem()}
    </Grid>
  );
});

const mapStateToProps = ({ assignments, user }) => {
  return {
    assignmentId: assignments.assignment && assignments.assignment.id,
    userId: user.userId
  };
};

const mapDispatchToProps = dispatch => {
  return {
    ...bindActionCreators(backups_actions, dispatch)
  };
};

const ConnectedComponent = connect(
  mapStateToProps,
  mapDispatchToProps
)(ResponsiveImageItem);

export default withStyles(styles)(ConnectedComponent);
