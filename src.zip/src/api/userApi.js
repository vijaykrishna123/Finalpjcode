import axios from "axios";

import configDeterminator from "../configs/configDeterminator";

export const fetchInitialUsersAPI = payload => {
  let url = `${configDeterminator.legalApiEndpoint}/users`;
  return axios.get(url);
};
