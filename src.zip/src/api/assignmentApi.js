import configDeterminator from "../configs/configDeterminator";
import axios from "axios";

const { cmpApiEndpoint, cwbApiEndpoint } = configDeterminator;
export const getAssignmentDetails = postId => {
  return axios.get(cmpApiEndpoint + "/posts" + postId, {
    headers: {
      Accept: "application/json"
    }
  });
};

export const getDraftDetailsApi = postId => {
  return axios.get(`${configDeterminator.cwbApiEndpoint}/posts${postId}`, {
    headers: {
      Accept: "application/json"
    }
  });
};

export const createAssignmentDetails = assignmentData => {
  return axios.put(cwbApiEndpoint + "/assignment", {
    percolateId: assignmentData.percolateId,
    assignmentName: assignmentData.assignmentName,
    templateName: assignmentData.templateName,
    unlinkedAssignment: assignmentData.unlinkedAssignment,
    userInitials: assignmentData.userInitials,
    workfrontJobId: assignmentData.workfrontJobId,
    stateId: 2
  });
};
