import configDeterminator from "../configs/configDeterminator";
import axios from "axios";
import moment from "moment";
import getHeader from "../utils/cwbUtils";
const { discoverApi } = configDeterminator;

export const cognitiveSearch = payload => {
  return axios.post(
    `${discoverApi}/api/mss/advanced-search/v1/list`,
    { ...payload },
    { headers: getHeader() }
  );
};

export const feedbackApi = payload => {
  const body = {
    feedback: payload.feedback,
    feedback_type: "as",
    feedback_level: "snippet",
    query_id: payload.query_id,
    doc_id: payload.doc_id,
    section_id: payload.section_id,
    request: {
      session_id: localStorage.getItem("sessionId"),
      user_id: payload.user
    },
    is_nlp: true
  };

  return axios.post(
    `${configDeterminator.discoverApi}/api/mss/advanced-search/v1/feedback`,
    { ...body },
    { headers: getHeader() }
  );
};

export const filterApi = payload => {
  const body = {
    query: payload.query,
    offset: 0,
    source: [],
    file_type: [],
    time_filter_value: 36,
    sort_order: "relevance",
    query_id: payload.query_id,
    keyword_flag: true,
    request: {
      session_id: localStorage.getItem("sessionId"),
      user_id: payload.user,
      search_type: 1,
      query_type: "as"
    },
    is_nlp: true,
    publication_from_date: moment()
      .subtract(36, "months")
      .format("YYYY-MM-DD"),
    publication_to_date: moment().format("YYYY-MM-DD"),
    apply_filter: true
  };

  return axios.post(
    `${configDeterminator.discoverApi}/api/mss/advanced-search/v1/list`,
    { ...body },
    { headers: getHeader() }
  );
};

export const autocompleteApi = ({ userid, in_text }) => {
  return axios.get(
    `${
      configDeterminator.discoverApi
    }/api/mss/autocomplete/autocomplete?userid=${userid}&in_text=${in_text}`,
    { headers: getHeader() }
  );
};

export const autocorrectApi = payload => {
  const body = {
    user_query: payload
  };

  return axios.post(
    `${configDeterminator.discoverApi}/api/mss/autocorrect/autocorrect`,
    { ...body },
    { headers: getHeader() }
  );
};
