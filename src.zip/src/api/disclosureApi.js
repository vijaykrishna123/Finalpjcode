import axios from "axios";
import configDeterminator from "../configs/configDeterminator";

export const getDisclosureDetails = param => {
  return axios
    .post(
      "/services/api/v1/disclosure/digPreview?previewMode=languageAndPath&" +
        param,
      {
        headers: {
          Accept: "application/json"
        }
      }
    )
    .catch(error => {
      console.error(error);
    });
};

export const generatePdfAPI = payload => {
  return axios.post(
    `${configDeterminator.cwbApiEndpoint}/generate/disclosurePdf`,
    {
      disclosureTags: payload
    },
    { responseType: "arraybuffer" }
  );
};
