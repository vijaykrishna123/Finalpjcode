export const SEARCH_REQUEST = "[SEARCH] pass search query";
export const SEARCH_SUCCESS = "[SEARCH] Get Respose of search query";
export const SEARCH_FAIL = "[SEARCH] fail to get result of search query";

export const FEEDBACK_REQUEST = "[FEEDBACK] pass feedback query";
export const FEEDBACK_SUCCESS = "[FEEDBACK] Get Respose of feedback query";
export const FEEDBACK_FAIL = "[FEEDBACK] fail to get result of feedback query";

export const FILTER_REQUEST = "[FILTER] pass filter query";
export const FILTER_SUCCESS = "[FILTER] Get Respose of filter query";
export const FILTER_FAIL = "[FILTER] fail to get result of filter query";

export const AUTOCOMPLETE_REQUEST = "[AUTOCOMPLETE] pass autocomplete query";
export const AUTOCOMPLETE_SUCCESS =
  "[AUTOCOMPLETE] Get Respose of autocomplete query";
export const AUTOCOMPLETE_FAIL =
  "[AUTOCOMPLETE] fail to get result of autocomplete query";

export const AUTOCORRECT_REQUEST = "[AUTOCORRECT] pass autocorrect query";
export const AUTOCORRECT_SUCCESS =
  "[AUTOCORRECT] Get Respose of autocorrect query";
export const AUTOCORRECT_FAIL =
  "[AUTOCORRECT] fail to get result of autocorrect query";
export const CLEAR_STATE = "[CLEAR_STATE] reset the state";
export const CLEAR_AUTOCOMPLETE_STATE =
  "[CLEAR_AUTOCOMPLETE_STATE] reset the state";
