import {
  FETCH_ASSIGNMENT,
  FETCH_ASSIGNMENT_SUCCEEDED,
  FETCH_ASSIGNMENT_FAILED
} from "../constants/assignmentConstants";

import {
  FETCH_DRAFT_SUCCESS,
  FETCH_DRAFT_FAILED
} from "../constants/draftsConstants";

const initialState = {
  assignment: null,
  loading: false,
  error: false,
  postLoad: false,
  dashBoardLoaded: false
};

const assignmentReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_ASSIGNMENT:
      return {
        ...state,
        assignment: null,
        loading: true,
        error: false,
        dashBoardLoaded: false
      };

    case FETCH_ASSIGNMENT_SUCCEEDED:
    case FETCH_DRAFT_SUCCESS:
      return {
        ...state,
        assignment: action.payload,
        loading: false,
        error: false,
        dashBoardLoaded: false
      };
    case FETCH_ASSIGNMENT_FAILED:
    case FETCH_DRAFT_FAILED:
      return {
        ...state,
        assignment: null,
        loading: false,
        error: true
      };
    default:
      return state;
  }
};

export default assignmentReducer;
