import {
  ADD_DRAFT_ASSIGNMENT_SUCCESS,
  DELETE_DRAFT_ASSIGNMENT_SUCCESS,
  FETCH_ALL_DRAFTS_SUCCESS,
  SET_DRAFT_CREATING,
  SET_LINKING_STATUS
} from "../constants/draftsConstants";

const initialState = {
  drafts: [],
  draftCreating: false,
  linkingStatus: ""
};

const draftsReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_DRAFT_CREATING:
      return { ...state, draftCreating: action.payload.status };
    case SET_LINKING_STATUS:
      return { ...state, linkingStatus: action.payload.status };
    case ADD_DRAFT_ASSIGNMENT_SUCCESS:
      return {
        ...state,
        drafts: action.payload
      };

    case FETCH_ALL_DRAFTS_SUCCESS:
      return {
        ...state,
        drafts: action.payload
      };

    case DELETE_DRAFT_ASSIGNMENT_SUCCESS:
      let drafts = [...state.drafts];
      drafts = drafts.filter(draft => draft.id !== action.payload.id);
      return { ...state, drafts };

    default:
      return state;
  }
};

export default draftsReducer;
