import {
  FETCH_ALL_FIELDS_REQUEST,
  FETCH_ALL_FIELDS_SUCCESS,
  FETCH_ALL_FIELDS_FAILURE,
  FETCH_BACKUPS_SUCCESS,
  FETCH_COPY_SUCCESS,
  UPDATE_COPY_REQUEST,
  ADD_BACKUPS_ITEM_REQUEST,
  UPDATE_BACKUPS_ITEM_SUCCESS,
  DELETE_BACKUPS_ITEM_SUCCESS,
  UPDATE_GRAPHICS_ITEM_SUCCESS,
  DELETE_GRAPHIC_ITEM_SUCCESS,
  FETCH_BACKUPS_FAILURE,
  UPLOAD_COPY_FORM_DATA_SUCCESS,
  UPDATE_DISCLOSURE_TAGS_SUCCESS,
  PROOF_ACTION,
  CREATE_PROOF_REQUEST,
  CREATE_PROOF_SUCCESS,
  SAVE_ASSIGNMENT_SUCCEEDED,
  CLEAR_WRITE_STORE,
  UPDATE_WRITE_FOR_DISCLOSURE,
  ADD_COLLABORATOR_TO_WRITE_SUCCESS,
  REMOVE_COLLABORATOR_FROM_WRITE,
  CREATE_PROOF_PERSONAL_URL_SUCCESS,
  FETCH_REVIEWER_SUCCESS,
  START_LEGAL_REVIEW_SUCCESS,
  SEND_PDF_TO_WORKFRONT_SUCCESS
} from "../constants/writeConstants";
import _ from "lodash";
import Moment from "moment";

let initialState = {
  loading: false,
  write: {},
  error: false
};

const writeReducer = (state = initialState, action) => {
  switch (action.type) {
    case CLEAR_WRITE_STORE:
      return {};
    case FETCH_ALL_FIELDS_REQUEST:
      return {
        ...state,
        loading: true,
        error: false,
        proofStatus: "",
        proofUrl: [],
        personalUrl: ""
      };
    case FETCH_ALL_FIELDS_SUCCESS:
      let proofUrl = _.get(action, "payload.assignment.proofURL", "");
      if (proofUrl) {
        proofUrl = proofUrl.split("|");
        let proofFileId = _.get(action, "payload.assignment.proofFileId", null);
        proofUrl = proofUrl.map(proof => {
          return { proofUrl: proof, fileId: proofFileId };
        });
      }
      proofUrl = proofUrl || [];
      return {
        ...state,
        write: { ...action.payload },
        proofUrl,
        loading: false,
        error: false,
        showCreateReviewModal: false,
        showLegalReviewModal: false
      };
    case FETCH_ALL_FIELDS_FAILURE:
      return {
        ...state,
        loading: false,
        error: true
      };
    case FETCH_COPY_SUCCESS:
      return { ...state, copy: action.payload };
    case FETCH_BACKUPS_SUCCESS:
      return { ...state, backups: action.backupFields };
    case UPDATE_COPY_REQUEST:
      return updateCopyRequest(state, action);
    case SEND_PDF_TO_WORKFRONT_SUCCESS: {
      const newState = _.cloneDeep(state);
      if (newState.write.assignment) {
        newState.write.assignment.workfrontURL = action.payload.workfrontUrl;
      }
      return newState;
    }
    case ADD_BACKUPS_ITEM_REQUEST:
      let newState = _.cloneDeep(state);
      newState.write.backups.push(action.payload.backup);
      return newState;

    case UPDATE_BACKUPS_ITEM_SUCCESS:
      return updateBackup(state, action);
    case UPDATE_GRAPHICS_ITEM_SUCCESS:
      return updateGraphics(state, action);
    case DELETE_BACKUPS_ITEM_SUCCESS:
      return deleteBackup(state, action);
    case DELETE_GRAPHIC_ITEM_SUCCESS:
      return deleteGraphic(state, action);
    case FETCH_BACKUPS_FAILURE:
      return { ...state, write_error: action.error };
    case UPLOAD_COPY_FORM_DATA_SUCCESS:
      return { ...state, saveTime: Moment().format("MM/DD/YY [@] h:mm a") };
    // Update disclosureTags for saving into database
    case UPDATE_DISCLOSURE_TAGS_SUCCESS: {
      const newState = _.cloneDeep(state);
      if (newState.write.assignment) {
        newState.write.assignment.disclosureTags = action.payload;
      }
      return newState;
    }

    case PROOF_ACTION:
      return { ...state, proofStatus: action.payload.proofStatus };
    case CREATE_PROOF_REQUEST:
      return { ...state, proofStatus: "" };
    case CREATE_PROOF_SUCCESS:
      state.proofUrl && state.proofUrl.push(action.payload);
      return { ...state };
    case SAVE_ASSIGNMENT_SUCCEEDED:
      return {
        ...state,
        write: action.payload
      };
    case UPDATE_WRITE_FOR_DISCLOSURE:
      state.write.copy.fields[0].fieldValue = action.payload;
      return { ...state };
    case FETCH_REVIEWER_SUCCESS: {
      let newState = _.cloneDeep(state);
      newState.write.assignment.collaborators = _.uniqBy(
        newState.write.assignment.collaborators.concat(action.payload),
        "userInitials"
      );
      newState.write.assignment.reviewerLoaded = true;
      return newState;
    }

    case ADD_COLLABORATOR_TO_WRITE_SUCCESS: {
      const newState = _.cloneDeep(state);
      if (
        newState.write.assignment &&
        newState.write.assignment.collaborators
      ) {
        let isPresent = false;
        newState.write.assignment.collaborators.forEach(obj => {
          if (
            obj.userInitials &&
            action.payload.userInitials &&
            obj.userInitials.toLowerCase() ===
              action.payload.userInitials.toLowerCase()
          ) {
            isPresent = true;
          }
        });
        if (!isPresent) {
          newState.write.assignment.collaborators.push(action.payload);
        }
      }
      return newState;
    }
    case REMOVE_COLLABORATOR_FROM_WRITE:
      return {
        ...state,
        ...state.write.assignment.collaborators.splice(action.payload.index, 1)
      };

    case CREATE_PROOF_PERSONAL_URL_SUCCESS:
      return { ...state, personalUrl: action.payload.personalURL };

    case START_LEGAL_REVIEW_SUCCESS: {
      const newState = _.cloneDeep(state);
      if (newState.write.assignment) {
        if (!newState.write.assignment.workfrontDocId && action.payload.type === 'full') {
          newState.write.assignment.workfrontDocId = action.payload.DOCU_ID;
        }
        if (!newState.write.assignment.workfrontSocialDocId && action.payload.type === 'social') {
          newState.write.assignment.workfrontSocialDocId = action.payload.DOCU_ID;
        }
        if (!newState.write.assignment.workfrontLinkedDocId && action.payload.type === 'linked') {
          newState.write.assignment.workfrontLinkedDocId = action.payload.DOCU_ID;
        }
      }
      return newState;
    }

    default:
      return state;
  }
};

export default writeReducer;

function updateCopyRequest(state, action) {
  const key = Object.keys(action.payload)[0];
  if (!state.write || !state.write.copy || !state.write.copy.fields) {
    return state;
  }
  const index = _.findIndex(state.write.copy.fields, {
    fieldId: parseInt(key)
  });
  state.write.copy.fields[index].fieldValue = action.payload[key];
  return state;
}

function updateBackup(state, action) {
  let newState = _.cloneDeep(state);
  newState.write.backups = newState.write.backups.concat(action.payload);
  return newState;
}
function deleteBackup(state, action) {
  let newState = _.cloneDeep(state);
  const index = _.findIndex(newState.write.backups, {
    backupId: action.payload.backupId
  });
  newState.write.backups.splice(index, 1);
  return newState;
}

function updateGraphics(state, action) {
  let newState = _.cloneDeep(state);
  newState.write.graphics = newState.write.graphics.concat(action.payload);
  return newState;
}

function deleteGraphic(state, action) {
  let newState = _.cloneDeep(state);
  const index = _.findIndex(newState.write.graphics, {
    graphicsId: action.payload.graphicId
  });
  if (index > -1) {
    newState.write.graphics.splice(index, 1);
  }

  return newState;
}
