import _ from "lodash";
import {
  FETCH_ALL_ASSIGNMENT,
  FETCH_ALL_ASSIGNMENT_SUCCEEDED,
  FETCH_ALL_ASSIGNMENT_FAILED,
  ASSIGNMENT_DASHBOARD_LOADED,
  ASSIGNMENT_DASHBOARD_UNLOADED,
  FETCH_TEMPLATES_SUCCESS,
  FETCH_STATES_SUCCESS,
  CHANGE_STATE_SUCCESS
} from "../constants/dashBoardConstants";
import { UPDATE_ASSIGNMENT_STATUS_SUCCESS } from "../constants/assignmentConstants";

const initialState = {
  templates: [],
  allAssignments: [],
  loading: false,
  error: false,
  dashBoardLoaded: true,
  states: []
};

const dashBoardReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_ALL_ASSIGNMENT:
      return {
        ...state,
        allAssignments: [],
        loading: true,
        error: false
      };
    case FETCH_STATES_SUCCESS:
      return {
        ...state,
        states: action.payload
      };
    case CHANGE_STATE_SUCCESS:
      return updateAssignmentState(state, action);
    case FETCH_ALL_ASSIGNMENT_SUCCEEDED:
      return {
        ...state,
        allAssignments: action.payload,
        loading: false,
        error: false
      };
    case FETCH_ALL_ASSIGNMENT_FAILED:
      return {
        ...state,
        allAssignments: { assignments: [] },
        loading: false,
        error: true
      };
    case ASSIGNMENT_DASHBOARD_LOADED:
      return {
        ...state,
        dashBoardLoaded: true
      };
    case ASSIGNMENT_DASHBOARD_UNLOADED:
      return {
        ...state,
        dashBoardLoaded: false
      };
    case FETCH_TEMPLATES_SUCCESS:
      return {
        ...state,
        templates: action.payload
      };
    case UPDATE_ASSIGNMENT_STATUS_SUCCESS:
      return state;
    default:
      return state;
  }
};

function updateAssignmentState(state, action) {
  let newState = _.cloneDeep(state);
  const assignment = _.find(newState.allAssignments.assignments, {
    id: action.payload.assignmentId
  });
  if (assignment) {
    assignment.stateName = action.payload.stateName;
    assignment.stateId = action.payload.stateId;
  }
  return newState;
}

export default dashBoardReducer;
