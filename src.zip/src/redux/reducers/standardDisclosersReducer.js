import {
  FETCH_STD_DISCLOSURES,
  FETCH_STD_DISCLOSURES_SUCCEEDED,
  FETCH_STD_DISCLOSURES_FAILED
} from "../constants/standardDisclosuresConstants";


const initialState = {
  standardDisclosures: "<br/><strong>Investments are not FDIC-insured, nor are they deposits of or guaranteed by a bank or any other entity, so they may lose value.</strong><br/><br/><strong>Investors should carefully consider investment objectives, risks, charges and expenses. This and other important information is contained in the fund <a href='/advisor/investments/fund-literature.htm'>prospectuses and summary prospectuses</a>, which can be obtained from a financial professional and should be read carefully before investing.</strong><br/><br/>All Capital Group trademarks mentioned are owned by The Capital Group Companies, Inc., an affiliated company or fund. All other company and product names mentioned are the property of their respective companies.<br/><br/>Use of this website is intended for U.S. residents only.<br/><br/>American Funds Distributors, Inc., member FINRA.<br/><br/>This content, developed by Capital Group, home of American Funds, should not be used as a primary basis for investment decisions and is not intended to serve as impartial investment or fiduciary advice.<br/><br/>",
  loading: false,
  error: false
};

const standardDisclosuresReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_STD_DISCLOSURES:
      return {
        ...state,
        standardDisclosures: null,
        loading: true,
        error: false
      };
    case FETCH_STD_DISCLOSURES_SUCCEEDED:
      return {
        ...state,
        standardDisclosures: action.payload,
        loading: false,
        error: false
      };
    case FETCH_STD_DISCLOSURES_FAILED:
      return {
        ...state,
        standardDisclosures: null,
        loading: false,
        error: true
      };
    default:
      return state;
  }
};

export default standardDisclosuresReducer; 
