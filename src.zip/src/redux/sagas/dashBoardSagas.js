import { put, takeLatest, call } from "redux-saga/effects";
import {
  FETCH_ALL_ASSIGNMENT,
  FEEDBACK_SUBMIT_REQUEST,
  FETCH_TEMPLATES,
  FETCH_STATES,
  CHANGE_STATE,
  UPLOAD_TRANSFER_ZIP
} from "../constants/dashBoardConstants";

import {
  receiveAllAssignments,
  fetchErrorAllAssignments,
  fetchTemplatesSuccess,
  fetchTemplatesError,
  fetchStatesSuccess,
  fetchStatesError,
  changeStateSuccess,
  changeStateError
} from "../actions/dashBoardActions";
import {
  getAllAssignmentForUser,
  getAllRegularAssignmentsAPI,
  weneedfeedbackApi,
  fetchTemplatesAPI,
  fetchStatesAPI,
  changeStateAPI
} from "../../api/dashBoardApi";

import { startLegalReviewAPI, sendPdfToWorkfrontAPI } from "../../api/writeApi";

function* fetchAllAssignment(action) {
  try {
    const response = yield call(getAllAssignmentForUser, action.payload.email);
    const regularResponse = yield call(
      getAllRegularAssignmentsAPI,
      action.payload.username
    );
    let allAssignments = response.data ? response.data.assignments : [];

    if (
      allAssignments &&
      allAssignments.length &&
      regularResponse &&
      regularResponse.data &&
      regularResponse.data.length
    ) {
      allAssignments = allAssignments.map(assignment => {
        assignment.updatedAt = assignment.liveAt;
        for (let i = 0; i < regularResponse.data.length; i++) {
          if (regularResponse.data[i].percolateId === assignment.id) {
            assignment.proofURL = regularResponse.data[i].proofURL;
            assignment.workfrontDocsCount =
              regularResponse.data[i].workfrontDocsCount;
            if (regularResponse.data[i].updatedAt)
              assignment.updatedAt = regularResponse.data[i].updatedAt;
            if (regularResponse.data[i].stateName) {
              assignment.stateName = regularResponse.data[i].stateName;
              assignment.stateId = regularResponse.data[i].stateId;
            }
            break;
          }
        }
        return assignment;
      });
    }
    yield put(receiveAllAssignments({ assignments: allAssignments }));
  } catch (error) {
    yield put(fetchErrorAllAssignments(error));
  }
}

function* fetchTemplates() {
  try {
    const response = yield call(fetchTemplatesAPI);
    const filteredData = response.data.filter(
      template => ["Email", "Web Article"].indexOf(template.templateName) > -1
    );
    yield put(fetchTemplatesSuccess(filteredData));
  } catch (error) {
    yield put(fetchTemplatesError(error));
  }
}

function* fetchStates() {
  try {
    const response = yield call(fetchStatesAPI);
    yield put(fetchStatesSuccess(response.data));
  } catch (error) {
    yield put(fetchStatesError(error));
  }
}

function* changeState({ payload }) {
  try {
    yield call(changeStateAPI, payload);
    yield put(changeStateSuccess(payload));
  } catch (error) {
    yield put(changeStateError(error));
  }
}

function* submitUserFeedback({ payload }) {
  try {
    yield call(weneedfeedbackApi, payload);
    //yield put(showSuccessMsg("Thanks "));
  } catch (e) {
    //  yield put(showErrorMsg("API ERROR"));
  }
}

function* callUploadTransferZip({ payload }) {
  console.log("payload", payload);
  const { workfrontDocId, ...rest } = payload;
  try {
    const response = yield call(startLegalReviewAPI, {
      ...rest,
      documentId: workfrontDocId
    });
    console.log("response", response);
    const res = yield call(sendPdfToWorkfrontAPI, {
      id: payload.id, // payload.id is the percolate id of the assignment
      workfrontDocId: workfrontDocId || response.data.DOCU_ID,
      workfrontUrl: response.data.workfrontUrl,
      workfrontDocName: response.data.name || payload.workfrontDocName,
      workfrontDocVersion: response.data.lastVersionNum,
      pdfCategory: "FILING_ZIP"
    });
    console.log("res", res);
    // yield call(weneedfeedbackApi, payload);
    //yield put(showSuccessMsg("Thanks "));
  } catch (e) {
    //  yield put(showErrorMsg("API ERROR"));
  }
}

function* dashBoardSagas() {
  yield takeLatest(FETCH_ALL_ASSIGNMENT, fetchAllAssignment);
  yield takeLatest(FEEDBACK_SUBMIT_REQUEST, submitUserFeedback);
  yield takeLatest(FETCH_TEMPLATES, fetchTemplates);
  yield takeLatest(FETCH_STATES, fetchStates);
  yield takeLatest(CHANGE_STATE, changeState);
}

export default dashBoardSagas;
