import { put, takeLatest, call } from "redux-saga/effects";
import {
  FETCH_ASSIGNMENT,
  CREATE_ASSIGNMENT,
  UPDATE_ASSIGNMENT_STATUS_REQUEST
} from "../constants/assignmentConstants";

import {
  receiveAssignmentDetails,
  fetchErrorAssignmentDetails,
  receiveAssignmentSuccess,
  receiveAssignmentError
} from "../actions/assignmentActions";
import {
  getAssignmentDetails,
  createAssignmentDetails
} from "../../api/assignmentApi";
import { showErrorMsg } from "../actions/writeAction";
import { fetchAllAssignments } from "../actions/dashBoardActions";

function* fetchAssignmentDetails(action) {
  try {
    const response = yield call(getAssignmentDetails, action.payload);

    yield put(receiveAssignmentDetails(response.data));
  } catch (error) {
    yield put(fetchErrorAssignmentDetails(error));
  }
}

function* createAssignment(action) {
  try {
    const response = yield call(createAssignmentDetails, action.payload);
    yield put(receiveAssignmentSuccess(response.data));
  } catch (error) {
    yield put(receiveAssignmentError(error));
  }
}
function* updateAssignment({ payload }) {
  try {
    yield put(fetchAllAssignments(payload.email));
  } catch (error) {
    yield put(showErrorMsg("API Error "));
  }
}

function* assignmentSagas() {
  yield takeLatest(FETCH_ASSIGNMENT, fetchAssignmentDetails);
  yield takeLatest(CREATE_ASSIGNMENT, createAssignment);
  yield takeLatest(UPDATE_ASSIGNMENT_STATUS_REQUEST, updateAssignment);
}

export default assignmentSagas;
