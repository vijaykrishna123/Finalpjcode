import { put, takeLatest, call } from "redux-saga/effects";
import { GENERATE_PDF } from "../constants/disclosureConstants";
import { generatePdfAPI } from "../../api/disclosureApi";

function* gereratePdf(action) {
  console.log("GENERATE_PDF called saga", action);
  try {
    const response = yield call(generatePdfAPI, action.payload);
    var blob = new Blob([response.data], { type: "application/pdf" });
    var link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = "disclosure.pdf";
    link.click();
  } catch (error) {
    console.log("Something went wrong", error);
  }
}

function* disclosuresSagas() {
  yield takeLatest(GENERATE_PDF, gereratePdf);
}

export default disclosuresSagas;
