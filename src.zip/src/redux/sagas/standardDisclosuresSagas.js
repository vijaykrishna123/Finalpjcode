import { put, takeLatest, call } from "redux-saga/effects";
import { FETCH_STD_DISCLOSURES } from "../constants/standardDisclosuresConstants";

import {
  fetchErrorStdDisclosuresDetails,
  receiveStdDisclosuresDetails
} from "../actions/standardDisclosuresAction";

import { getDisclosureDetails } from "../../api/disclosureApi";

function* fetchsStandarddDisclosuresDetails(action) {
  try {
    const response = yield call(getDisclosureDetails, action.payload);
    yield put(receiveStdDisclosuresDetails(response.data));
  } catch (error) {
    yield put(fetchErrorStdDisclosuresDetails(error));
  }
}


function* standardDisclosuresSagas() {
  yield takeLatest(FETCH_STD_DISCLOSURES, fetchsStandarddDisclosuresDetails);
  
}

export default standardDisclosuresSagas;
