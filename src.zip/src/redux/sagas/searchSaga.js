import { put, takeLatest, call } from "redux-saga/effects";
import { recordSearchTermAnalytics } from "../../components/Analytics/Analytics";
import {
  SEARCH_REQUEST,
  FEEDBACK_REQUEST,
  FILTER_REQUEST,
  AUTOCOMPLETE_REQUEST,
  AUTOCORRECT_REQUEST
} from "../constants/searchConstant";
import { showErrorMsg, showSuccessMsg } from "../actions/writeAction";
import {
  cognitiveSearch,
  feedbackApi,
  filterApi,
  autocompleteApi,
  autocorrectApi
} from "../../api/cognitiveSearchApi";
import {
  searchSuccess,
  feedbackSuccess,
  filterSuccess,
  autocompleteSuccess,
  autocorrectSuccess,
  searchRequestFail
} from "../actions/searchAction";

function* querySearchRequest({ payload }) {
  try {
    let response = yield call(cognitiveSearch, payload);
    yield put(searchSuccess(response.data));
    if (
      response.data.hasOwnProperty("query") &&
      response.data.hasOwnProperty("record_count")
    ) {
      recordSearchTermAnalytics(
        response.data.query,
        response.data.record_count,
        "research"
      );
    }
  } catch (error) {
    yield put(showErrorMsg("API error"));
    yield put(searchRequestFail());
  }
}
function* feedbackRequest({ payload }) {
  try {
    let response = yield call(feedbackApi, payload);
    yield put(feedbackSuccess(response.data));
    yield put(showSuccessMsg("Thanks for your feedback"));
  } catch (error) {
    yield put(showErrorMsg("API error"));
  }
}

function* filterRequest({ payload }) {
  try {
    let response = yield call(filterApi, payload);
    yield put(filterSuccess(response.data));
  } catch (error) {
    yield put(showErrorMsg("API error"));
  }
}

function* autocompleteRequest({ payload }) {
  try {
    let response = yield call(autocompleteApi, payload);
    let result;
    if (response.data.length) {
      result = response.data;
    } else {
      result = ["No Results "];
    }
    yield put(autocompleteSuccess(result));
  } catch (error) {
    yield put(showErrorMsg("API error"));
  }
}

function* autocorrectRequest({ payload }) {
  try {
    let response = yield call(autocorrectApi, payload);
    if (response) yield put(autocorrectSuccess(response.data));
  } catch (error) {
    yield put(showErrorMsg("AUTOCORRECT API error"));
  }
}

function* searchSaga() {
  yield takeLatest(SEARCH_REQUEST, querySearchRequest);
  yield takeLatest(FEEDBACK_REQUEST, feedbackRequest);

  yield takeLatest(FILTER_REQUEST, filterRequest);
  yield takeLatest(AUTOCOMPLETE_REQUEST, autocompleteRequest);
  yield takeLatest(AUTOCORRECT_REQUEST, autocorrectRequest);
}

export default searchSaga;
