import { put, takeLatest, call } from "redux-saga/effects";
import {
  SHARE_URL_TO_OTHER,
  RELATED_PROJECTS_REQUEST,
  DELETE_PROJECT_REQUEST
} from "../constants/commentConstant";
import {
  getProjectsApi,
  shareurlAPI,
  deleteProjects
} from "../../api/dashBoardApi";
import {
  shareRelatedProjectsResponse,
  shareRelatedProjectsError,
  deleteProjectSuccess
} from "../actions/commentAction";
import { showErrorMsg, showSuccessMsg } from "../actions/writeAction";

function* shareUrlToOther({ payload }) {
  try {
    yield call(shareurlAPI, payload);
    yield put(showSuccessMsg("Email sent"));
  } catch (e) {
    yield put(showErrorMsg("Unable to sent email"));
    console.error(e);
  }
}
function* shareRelatedProjects({ payload }) {
  try {
    const res = yield call(getProjectsApi, payload);
    yield put(shareRelatedProjectsResponse(res.data));
  } catch (e) {
    yield put(shareRelatedProjectsError());
    yield put(showErrorMsg("Unable to fetch related assignments"));
    console.error(e);
  }
}

function* deleteProject({ payload }) {
  try {
    yield call(deleteProjects, payload.commentId);
    yield put(deleteProjectSuccess(payload.commentId));
    yield put(showSuccessMsg("Deleted Successfully"));
  } catch (error) {
    yield put(showErrorMsg("Error for deleting assignment"));
  }
}

function* commentSagas() {
  yield takeLatest(SHARE_URL_TO_OTHER, shareUrlToOther);
  yield takeLatest(RELATED_PROJECTS_REQUEST, shareRelatedProjects);
  yield takeLatest(DELETE_PROJECT_REQUEST, deleteProject);
}

export default commentSagas;
