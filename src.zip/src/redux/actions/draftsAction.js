import {
  ADD_DRAFT_ASSIGNMENT,
  DELETE_DRAFT_ASSIGNMENT,
  DELETE_DRAFT_ASSIGNMENT_SUCCESS,
  DELETE_DRAFT_ASSIGNMENT_FAILED,
  ADD_DRAFT_ASSIGNMENT_SUCCESS,
  ADD_DRAFT_ASSIGNMENT_ERROR,
  FETCH_ALL_DRAFTS,
  FETCH_ALL_DRAFTS_SUCCESS,
  FETCH_ALL_DRAFTS_FAILED,
  FETCH_DRAFT,
  FETCH_DRAFT_FAILED,
  FETCH_DRAFT_SUCCESS,
  LINK_DRAFT,
  LINK_DRAFT_FAILED,
  LINK_DRAFT_SUCCESS,
  SET_DRAFT_CREATING,
  SET_LINKING_STATUS
} from "../constants/draftsConstants";
import { openSnackbar } from "../../components/Popups/CWBSnackBar";

export const showSuccessMsg = message => {
  openSnackbar({ message: message, variant: "success" });
  return {
    type: "SUCCESS"
  };
};

export const showErrorMsg = message => {
  openSnackbar({ message: message, variant: "error" });
  return {
    type: "ERROR"
  };
};

export const fetchAllDrafts = username => ({
  type: FETCH_ALL_DRAFTS,
  payload: username
});

export const fetchAllDraftsError = error => ({
  type: FETCH_ALL_DRAFTS_FAILED,
  payload: error
});

export const fetchAllDraftsSuccess = assignmentDetails => ({
  type: FETCH_ALL_DRAFTS_SUCCESS,
  payload: assignmentDetails
});

export const fetchDraftDetail = payload => ({
  type: FETCH_DRAFT,
  payload
});

export const fetchDraftError = error => ({
  type: FETCH_DRAFT_FAILED,
  payload: error
});

export const fetchDraftSuccess = draft => ({
  type: FETCH_DRAFT_SUCCESS,
  payload: draft
});

export const linkDraftToAssignment = payload => ({
  type: LINK_DRAFT,
  payload
});

export const linkDraftToAssignmentError = error => ({
  type: LINK_DRAFT_FAILED,
  payload: error
});

export const linkDraftToAssignmentSuccess = draft => ({
  type: LINK_DRAFT_SUCCESS,
  payload: draft
});

export const addDraft = payload => {
  return {
    type: ADD_DRAFT_ASSIGNMENT,
    payload
  };
};

export const setDraftCreating = payload => {
  return {
    type: SET_DRAFT_CREATING,
    payload
  };
};

export const setLinkingStatus = payload => {
  return {
    type: SET_LINKING_STATUS,
    payload
  };
};

export const receiveDraftAssignmentSuccess = payload => {
  return {
    type: ADD_DRAFT_ASSIGNMENT_SUCCESS,
    payload
  };
};

export const receiveDraftAssignmentError = payload => {
  return {
    type: ADD_DRAFT_ASSIGNMENT_ERROR,
    payload
  };
};

export const deleteDraft = payload => {
  return {
    type: DELETE_DRAFT_ASSIGNMENT,
    payload
  };
};

export const deleteDraftSuccess = payload => {
  return {
    type: DELETE_DRAFT_ASSIGNMENT_SUCCESS,
    payload
  };
};

export const deleteDraftFailed = payload => {
  return {
    type: DELETE_DRAFT_ASSIGNMENT_FAILED,
    payload
  };
};
