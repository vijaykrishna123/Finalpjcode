import {
  SHARE_URL_TO_OTHER,
  RELATED_PROJECTS_REQUEST,
  RELATED_PROJECTS_SUCCESS,
  RELATED_PROJECTS_ERROR,
  DELETE_PROJECT_REQUEST,
  DELETE_PROJECT_SUCCESS
} from "../constants/commentConstant";

export const shareUrlToOther = payload => ({
  type: SHARE_URL_TO_OTHER,
  payload
});

export const shareRelatedProjects = payload => ({
  type: RELATED_PROJECTS_REQUEST,
  payload
});

export const shareRelatedProjectsResponse = payload => ({
  type: RELATED_PROJECTS_SUCCESS,
  payload
});

export const shareRelatedProjectsError = payload => ({
  type: RELATED_PROJECTS_ERROR,
  payload
});

export const deleteProjectSuccess = payload => {
  return {
    type: DELETE_PROJECT_SUCCESS,
    payload
  };
};

export const deleteProjectRequest = payload => {
  return {
    type: DELETE_PROJECT_REQUEST,
    payload
  };
};
