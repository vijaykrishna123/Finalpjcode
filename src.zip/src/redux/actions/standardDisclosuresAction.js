import {
  FETCH_STD_DISCLOSURES,
  FETCH_STD_DISCLOSURES_SUCCEEDED,
  FETCH_STD_DISCLOSURES_FAILED
} from "../constants/standardDisclosuresConstants";

/**
 * Method for fetching the standard disclosures from AEM
 */

export const fetchsStdDisclosuresDetails = (param) => ({
    type: FETCH_STD_DISCLOSURES,
    payload:param
}); 
/**
 * Function in case we get error while getting standard disclosures
 */
export const fetchErrorStdDisclosuresDetails = error => ({
  type: FETCH_STD_DISCLOSURES_FAILED,
  payload: error
});

/**
 * Function for dispatching once the standard disclosures are received
 */
export const receiveStdDisclosuresDetails = stdDisclosuresDetails => ({
  type:  FETCH_STD_DISCLOSURES_SUCCEEDED,
  payload: stdDisclosuresDetails
});


