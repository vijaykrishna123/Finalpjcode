export const APPLICATION_JSON = "application/json";
