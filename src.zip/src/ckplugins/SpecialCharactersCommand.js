import Command from "@ckeditor/ckeditor5-core/src/command";

export default class SpecialCharactersCommand extends Command {
  execute({ value }) {
    const editor = this.editor;

    editor.model.change(writer => {
      // Create a <placeholder> elment with the "name" attribute...
      const specialCharacter = writer.createText(value);

      // ... and insert it into the document.
      editor.model.insertContent(specialCharacter);

      // Put the selection on the inserted element.
      // writer.setSelection(specialCharacter, "on");
    });
  }

  refresh() {
    const model = this.editor.model;
    const selection = model.document.selection;

    const isAllowed = model.schema.checkChild(
      selection.focus.parent,
      "specialchars"
    );

    this.isEnabled = isAllowed;
  }
}
